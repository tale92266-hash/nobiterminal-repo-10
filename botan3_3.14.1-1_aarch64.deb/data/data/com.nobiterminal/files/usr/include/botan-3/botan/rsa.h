/*
* RSA
* (C) 1999-2008,2016 Jack Lloyd
*
* Botan is released under the Simplified BSD License (see license.txt)
*/

#ifndef BOTAN_RSA_H_
#define BOTAN_RSA_H_

#include <botan/bigint.h>
#include <botan/pk_keys.h>
#include <memory>
#include <string>
#include <vector>

namespace Botan {

class RSA_Public_Data;
class RSA_Private_Data;

/**
* RSA Public Key
*/
class BOTAN_PUBLIC_API(2, 0) RSA_PublicKey : public virtual Public_Key {
   public:
      /**
      * Load a public key.
      * @param alg_id the X.509 algorithm identifier
      * @param key_bits DER encoded public key bits
      */
      RSA_PublicKey(const AlgorithmIdentifier& alg_id, std::span<const uint8_t> key_bits);

      /**
      * Create a public key.
      * @arg n the modulus
      * @arg e the exponent
      */
      RSA_PublicKey(const BigInt& n, const BigInt& e);

      std::string algo_name() const override { return "RSA"; }

      bool check_key(RandomNumberGenerator& rng, bool strong) const override;

      AlgorithmIdentifier algorithm_identifier() const override;

      std::vector<uint8_t> raw_public_key_bits() const override;

      std::vector<uint8_t> public_key_bits() const override;

      /**
      * @return public modulus
      */
      const BigInt& get_n() const;

      /**
      * @return public exponent
      */
      const BigInt& get_e() const;

      size_t key_length() const override;
      size_t estimated_strength() const override;

      const BigInt& get_int_field(std::string_view field) const override;

      std::unique_ptr<Private_Key> generate_another(RandomNumberGenerator& rng) const override;

      bool supports_operation(PublicKeyOperation op) const override;

      // internal functions:
      std::shared_ptr<const RSA_Public_Data> public_data() const;

      std::unique_ptr<PK_Ops::Encryption> _create_encryption_op(
         RandomNumberGenerator& rng, const PK_Encryption_Options_Reader& options) const override;

      std::unique_ptr<PK_Ops::KEM_Encryption> _create_kem_encryption_op(
         const PK_KEM_Options_Reader& options) const override;

      std::unique_ptr<PK_Ops::Verification> _create_verification_op(
         const PK_Signature_Options_Reader& options) const override;

      std::unique_ptr<PK_Ops::Verification> create_x509_verification_op(const AlgorithmIdentifier& alg_id,
                                                                        std::string_view provider) const override;

   protected:
      RSA_PublicKey() = default;

      void init(BigInt&& n, BigInt&& e);

      std::shared_ptr<const RSA_Public_Data> m_public;  // NOLINT(*non-private-member-variable*)
};

/**
* RSA Private Key
*/

BOTAN_DIAGNOSTIC_PUSH
BOTAN_DIAGNOSTIC_IGNORE_INHERITED_VIA_DOMINANCE

class BOTAN_PUBLIC_API(2, 0) RSA_PrivateKey final : public virtual Private_Key,
                                                    public virtual RSA_PublicKey {
   public:
      /**
      * Load a private key.
      * @param alg_id the X.509 algorithm identifier
      * @param key_bits PKCS#1 RSAPrivateKey bits
      */
      RSA_PrivateKey(const AlgorithmIdentifier& alg_id, std::span<const uint8_t> key_bits);

      /**
      * Construct a private key from the specified parameters.
      * @param p the first prime
      * @param q the second prime
      * @param e the exponent
      * @param d if specified, this has to be d with
      * exp * d = 1 mod (p - 1, q - 1). Leave it as 0 if you wish to
      * the constructor to calculate it.
      * @param n if specified, this must be n = p * q. Leave it as 0
      * if you wish to the constructor to calculate it.
      */
      RSA_PrivateKey(const BigInt& p,
                     const BigInt& q,
                     const BigInt& e,
                     const BigInt& d = BigInt::zero(),
                     const BigInt& n = BigInt::zero());

      /**
      * Create a new private key with the specified bit length
      * @param rng the random number generator to use
      * @param bits the desired bit length of the private key
      * @param exp the public exponent to be used
      */
      RSA_PrivateKey(RandomNumberGenerator& rng, size_t bits, size_t exp = 65537);

      std::unique_ptr<Public_Key> public_key() const override;

      bool check_key(RandomNumberGenerator& rng, bool strong) const override;

      const BigInt& get_int_field(std::string_view field) const override;

      /**
      * Get the first prime p.
      * @return prime p
      */
      const BigInt& get_p() const;

      /**
      * Get the second prime q.
      * @return prime q
      */
      const BigInt& get_q() const;

      /**
      * Get d with exp * d = 1 mod (p - 1, q - 1).
      * @return d
      */
      const BigInt& get_d() const;

      const BigInt& get_c() const;
      const BigInt& get_d1() const;
      const BigInt& get_d2() const;

      secure_vector<uint8_t> private_key_bits() const override;

      // internal functions:
      std::shared_ptr<const RSA_Private_Data> private_data() const;

      std::unique_ptr<PK_Ops::Decryption> _create_decryption_op(
         RandomNumberGenerator& rng, const PK_Encryption_Options_Reader& options) const override;

      std::unique_ptr<PK_Ops::KEM_Decryption> _create_kem_decryption_op(
         RandomNumberGenerator& rng, const PK_KEM_Options_Reader& options) const override;

      std::unique_ptr<PK_Ops::Signature> _create_signature_op(
         RandomNumberGenerator& rng, const PK_Signature_Options_Reader& options) const override;

   private:
      void init(BigInt&& d, BigInt&& p, BigInt&& q, BigInt&& d1, BigInt&& d2, BigInt&& c);

      std::shared_ptr<const RSA_Private_Data> m_private;
};

BOTAN_DIAGNOSTIC_POP

}  // namespace Botan

#endif
