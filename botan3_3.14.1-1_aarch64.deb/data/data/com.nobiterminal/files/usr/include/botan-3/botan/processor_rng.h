/*
* (C) 2016,2019,2020 Jack Lloyd
*
* Botan is released under the Simplified BSD License (see license.txt)
*/

#ifndef BOTAN_RNG_PROCESSOR_RNG_H_
#define BOTAN_RNG_PROCESSOR_RNG_H_

#include <botan/rng.h>

namespace Botan {

/**
* Directly invokes a CPU specific instruction to generate random numbers.
* On x86, the RDRAND instruction is used.
* On POWER, the DARN instruction is used.
* On AArch64, the RNDR instruction is used.
*/
class BOTAN_PUBLIC_API(2, 15) Processor_RNG final : public Hardware_RNG {
   public:
      /**
      * Constructor will throw if the CPU does not support the RNG instruction
      */
      Processor_RNG();

      /**
      * Return true if RNG instruction is available on the current processor
      */
      static bool available();

      /**
      * Test whether this RNG accepts externally provided input
      * @return false if this RNG is known to ignore provided inputs
      */
      bool accepts_input() const override { return false; }

      /**
      * Test whether this RNG has been seeded
      * @return true if this RNG is seeded and ready for use
      */
      bool is_seeded() const override { return true; }

      /**
      * Return the name of this RNG type
      * @return the name of this RNG type
      */
      std::string name() const override;

   private:
      void fill_bytes_with_input(std::span<uint8_t> out, std::span<const uint8_t> in) override;
};

}  // namespace Botan

#endif
