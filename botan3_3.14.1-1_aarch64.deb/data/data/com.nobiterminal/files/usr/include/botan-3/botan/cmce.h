/*
 * Classic McEliece Key Generation
 * (C) 2023 Jack Lloyd
 *     2023,2024 Fabian Albert, Amos Treiber - Rohde & Schwarz Cybersecurity
 *
 * Botan is released under the Simplified BSD License (see license.txt)
 **/

#ifndef BOTAN_CMCE_H_
#define BOTAN_CMCE_H_

#include <botan/pk_keys.h>

#include <botan/cmce_parameter_set.h>

namespace Botan {

class Classic_McEliece_PublicKeyInternal;
class Classic_McEliece_PrivateKeyInternal;

/**
 * Classic McEliece is a Code-Based KEM. It was a round 4 candidate in NIST's PQC competition and was
 * standardized by ISO in June 2026 (ISO/IEC 18033-2:2006/Amd 2). It is endorsed by the German Federal
 * Office for Information Security (BSI) for its conservative security assumptions. Both NIST and ISO
 * parameter sets are implemented here. As the ISO document is not freely available, see
 * https://classic.mceliece.org/ for the specification this implementation follows; the ISO standard
 * is stated by the Classic McEliece team to be compatible with it.
 *
 * Advantages of Classic McEliece:
 * - Conservative post-quantum security assumptions
 * - Very fast encapsulation
 * - Fast decapsulation
 *
 * Disadvantages of Classic McEliece:
 * - Very large public keys (0.26 MB - 1.36 MB)
 * - Relatively slow key generation
 * - Algorithm is complex and hard to implement side-channel resistant
 *
 * Note that recent research suggests that the security of Classic McEliece may
 * be significantly lower than what was previously thought. As of Sep 2026, BSI
 * recommends that Classic McEliece "should currently no longer be used in new
 * developments or when planning new cryptographic applications" and that any
 * usage of it be done as a hybrid KEM, paired with some other algorithm, such
 * as an EC or lattice-based scheme.
 */
class BOTAN_PUBLIC_API(3, 7) Classic_McEliece_PublicKey : public virtual Public_Key {
   public:
      /**
       * @brief Load a Classic McEliece public key from bytes.
       *
       * @param alg_id The algorithm identifier
       * @param key_bits The public key bytes
       */
      Classic_McEliece_PublicKey(const AlgorithmIdentifier& alg_id, std::span<const uint8_t> key_bits);

      /**
       * @brief Load a Classic McEliece public key from bytes.
       *
       * @param key_bits The public key bytes
       * @param param_set The parameter set
       */
      Classic_McEliece_PublicKey(std::span<const uint8_t> key_bits, Classic_McEliece_Parameter_Set param_set);

      Classic_McEliece_PublicKey(const Classic_McEliece_PublicKey& other);
      Classic_McEliece_PublicKey& operator=(const Classic_McEliece_PublicKey& other);
      Classic_McEliece_PublicKey(Classic_McEliece_PublicKey&&) = default;
      Classic_McEliece_PublicKey& operator=(Classic_McEliece_PublicKey&&) = default;

      ~Classic_McEliece_PublicKey() override = default;

      std::string algo_name() const override { return "ClassicMcEliece"; }

      AlgorithmIdentifier algorithm_identifier() const override;

      OID object_identifier() const override;

      size_t key_length() const override;

      size_t estimated_strength() const override;

      std::vector<uint8_t> public_key_bits() const override;

      std::vector<uint8_t> raw_public_key_bits() const override;

      bool check_key(RandomNumberGenerator& rng, bool strong) const override;

      bool supports_operation(PublicKeyOperation op) const override {
         return (op == PublicKeyOperation::KeyEncapsulation);
      }

      std::unique_ptr<Private_Key> generate_another(RandomNumberGenerator& rng) const final;

      std::unique_ptr<PK_Ops::KEM_Encryption> _create_kem_encryption_op(
         const PK_KEM_Options_Reader& options) const override;

   protected:
      Classic_McEliece_PublicKey() = default;

   protected:
      std::shared_ptr<const Classic_McEliece_PublicKeyInternal> m_public;  // NOLINT(*-non-private-member-variable*)
};

BOTAN_DIAGNOSTIC_PUSH
BOTAN_DIAGNOSTIC_IGNORE_INHERITED_VIA_DOMINANCE

class BOTAN_PUBLIC_API(3, 7) Classic_McEliece_PrivateKey final : public virtual Classic_McEliece_PublicKey,
                                                                 public virtual Private_Key {
   public:
      /**
       * @brief Create a new Classic McEliece private key for a specified parameter set.
       *
       * @param rng A random number generator
       * @param param_set The parameter set to use
       */
      Classic_McEliece_PrivateKey(RandomNumberGenerator& rng, Classic_McEliece_Parameter_Set param_set);

      /**
       * @brief Load a Classic McEliece private key from bytes.
       *
       * @param sk The private key bytes
       * @param param_set The parameter set to use
       */
      Classic_McEliece_PrivateKey(std::span<const uint8_t> sk, Classic_McEliece_Parameter_Set param_set);

      /**
       * @brief Load a Classic McEliece private key from bytes.
       *
       * @param alg_id The algorithm identifier
       * @param key_bits The private key bytes
       */
      Classic_McEliece_PrivateKey(const AlgorithmIdentifier& alg_id, std::span<const uint8_t> key_bits);

      std::unique_ptr<Public_Key> public_key() const override;

      secure_vector<uint8_t> private_key_bits() const override;

      secure_vector<uint8_t> raw_private_key_bits() const override;

      bool check_key(RandomNumberGenerator& rng, bool strong) const override;

      std::unique_ptr<PK_Ops::KEM_Decryption> _create_kem_decryption_op(
         RandomNumberGenerator& rng, const PK_KEM_Options_Reader& options) const override;

   private:
      std::shared_ptr<const Classic_McEliece_PrivateKeyInternal> m_private;
};

BOTAN_DIAGNOSTIC_POP

}  // namespace Botan

#endif  // BOTAN_CMCE_H_
