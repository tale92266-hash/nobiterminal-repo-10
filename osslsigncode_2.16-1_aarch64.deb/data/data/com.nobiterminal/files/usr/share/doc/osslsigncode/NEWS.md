# osslsigncode change log

### 2.16 (2026.11.13)

**Security fixes**

- fixed heap overflow when extracting script signature blocks larger than
  2 GiB (thanks to Lucidsec for reporting the issue)
- fixed buffer overflows in script UTF conversions on 32-bit builds, and
  out-of-bounds reads in scripts with odd UTF-16 sizes or signature blocks
  at the start of the file
- fixed double free and invalid memory reads when verifying malformed
  PKCS#7 content with OpenSSL older than 3.5 (thanks to smaeljaish771 for
  reporting the double free)
- fixed use-after-free and double free of CRLs embedded in signatures;
  these CRLs can be added to signed files without invalidating signatures
- fixed invalid pointer use with non-signedData Authenticode timestamp
  responses, MSI signatures, and "-spc" or "-certs" files
- fixed crashes on signatures or nested signatures with missing PKCS#7
  content (thanks to Małgorzata Olszówka)
- fixed invalid pointer dereferences when processing malformed catalog
  members, PE page hashes, or PKCS#7 certificate files without certificates
- fixed process memory disclosure into output files when PE or CAB
  signature offsets overlap headers, and out-of-bounds reads when parsing
  PE headers near the end of files approaching 4 GiB
- fixed out-of-bounds reads and possible memory disclosure with truncated
  CAB headers or unterminated cabinet names; malformed names are also
  rejected during digest calculation (thanks to Małgorzata Olszówka)
- fixed out-of-bounds reads in truncated MSI files and invalid sector
  references, and stack exhaustion with long directory chains or deeply
  nested storages
- fixed stack buffer overflow with oversized "-readpass" files on Windows,
  and buffer underflow with "-askpass" input starting with a NUL character
- enabled ASLR in prebuilt Linux binaries through static PIE, and added
  release asset attestations and build metadata

**Other user-visible changes**

- fixed corrupted output and failed verification when signing MSI files
  with empty or nested storages, or signing/removing signatures when the
  output has no streams smaller than 4 KiB
- fixed replacing or removing duplicate MSI DigitalSignature streams
- fixed opening MSI files whose directory starts at the first sector, and
  spurious sector-chain errors when reading MSI streams
- fixed crashes and invalid output on memory allocation failures during
  MSI signing and script UTF conversion
- fixed "remove-signature" reporting success and keeping truncated output
  for CAB files with corrupted headers
- fixed "-askpass" truncating passwords not terminated with a newline
- made warnings about ignored file-format options consistent and removed
  duplicate warnings
- included license files in prebuilt binary archives

### 2.15 (2026.11.06)

**Security fixes**

This release fixes timestamp verification flaws and memory-safety issues
present in 2.14. Users processing untrusted files are strongly encouraged
to upgrade.

- fixed verification to report failure when timestamp verification fails,
  unless "-ignore-timestamp" is used (thanks to Małgorzata Olszówka)
- fixed timestamp verification to use the time belonging to the verified
  timestamp when multiple timestamp attributes are present
- fixed RFC 3161 timestamp verification to reject truncated or overlong
  message imprints, preventing incorrect timestamp acceptance and
  out-of-bounds reads
- fixed replacing a script signature block that starts the file or follows a
  line with a different line ending, which crashed, deleted script content, or
  produced unverifiable output
- fixed use-after-free when replacing an existing APPX signature
- fixed heap out-of-bounds read and possible information disclosure when
  printing an empty PKCS#7 message digest
- fixed heap out-of-bounds reads when parsing malformed APPX ZIP64 extra fields
- fixed heap out-of-bounds reads when verifying malformed PKCS#7 signature
  attributes
- fixed buffer overflows when more than 256 occurrences of either "-t" or
  "-ts" are supplied

**Other user-visible changes**

- added prebuilt binaries for Linux, macOS and Windows on x86-64 and ARM64
  (thanks to Elijah Marusawa)
- added support for CMS OCTET STRING-encoded Authenticode content
  (thanks to Małgorzata Olszówka)
- improved PE checksum calculation performance (thanks to Francois Girinon)
- fixed compilation on Cygwin
- fixed compilation on Windows ARM64 (thanks to Elijah Marusawa)
- fixed signing large PE files with page hashes ("-ph"), including files with
  large overlays (thanks to Francois Girinon)
- fixed MSI MsiDigitalSignatureEx digest ordering during signing and
  verification, and validation of the metadata digest; files previously
  signed with "-add-msi-dse" whose streams sort before MsiDigitalSignatureEx
  must be re-signed. Corrected signatures will not verify with versions
  older than 2.15 (thanks to Małgorzata Olszówka)

### 2.14 (2026.07.20)

- added comprehensive command documentation in Markdown; man page and HTML
  versions are generated when Pandoc is available
- CMake installations now honor standard GNU install directories, include
  README and NEWS, and can be uninstalled
- attach-signature now uses digest-only verification instead of full signature
  validation; output file is not kept if digest verification fails
- fixed a memory leak when rejecting invalid compressed APPX data

### 2.13 (2026.02.10)

**MULTIPLE SECURITY VULNERABILITIES**

This release includes important security fixes. Users are strongly encouraged
to upgrade, as the issues below may be exploitable when processing untrusted
files.

- fixed integer overflows when processing APPX compressed data streams
  (by Małgorzata Olszówka)
- fixed double-free vulnerabilities in APPX file processing
  (by Małgorzata Olszówka)
- fixed multiple memory corruption issues in PE page hash computation
  (by Antoni Klajn (Opera) and Małgorzata Olszówka)

### 2.12 (2026.02.02)

**CRITICAL SECURITY VULNERABILITY**

This release fixes a critical memory corruption vulnerability.  A malicious
attacker could create a signed file, which, when verified with osslsigncode,
triggers arbitrary code execution.  Any previous version of osslsigncode should
be immediately upgraded if the tool is used for verification of untrusted
files.

- fixed a buffer overflow while extracting message digests
  (reported and fixed by Antoni Klajn, Opera)

### 2.11 (2026.01.20)
- added keyUsage validation for signer certificate
  (thanks to Hanqing Zhao and Zi-Quan You for reporting the issue)
- added printing CRL details during signature verification
- implemented a workaround for CRL servers returning the HTTP Content-Type
  header other than application/pkix-crl (thanks to Chris Thibodeaux)
- fixed HTTP keep-alive handling
- fixed macOS compiler and linker flags
- fixed undefined BIO_get_fp() behavior with BIO_FLAGS_UPLINK_INTERNAL

### 2.10 (2025.06.23)

- added JavaScript signing
- added PKCS#11 provider support (requires OpenSSL 3.0+)
- added support for providers without specifying "-pkcs11module" option
  (OpenSSL 3.0+, e.g., for the upcoming CNG provider)
- added compatibility with the CNG engine version 1.1 or later
- added the "-engineCtrl" option to control hardware and CNG engines
- added the '-blobFile' option to specify a file containing the blob content
- improved unauthenticated blob support (thanks to Asger Hautop Drewsen)
- improved UTF-8 handling for certificate subjects and issuers
- fixed support for multiple signerInfo contentType OIDs (CTL and Authenticode)
- fixed tests for python-cryptography >= 43.0.0

### 2.9 (2024.06.29)

- added a 64 bit long pseudo-random NONCE in the TSA request
- missing NID_pkcs9_signingTime is no longer an error
- added support for PEM-encoded CRLs
- fixed the APPX central directory sorting order
- added a special "-" file name to read the passphrase from stdin
  (by Steve McIntyre)
- used native HTTP client with OpenSSL 3.x, removing libcurl dependency
- added '-login' option to force a login to PKCS11 engines
  (by Brad Hughes)
- added the "-ignore-crl" option to disable fetching and verifying
  CRL Distribution Points
- changed error output to stderr instead of stdout
- various testing framework improvements
- various memory corruption fixes

### 2.8 (2024.03.03)

- Microsoft PowerShell signing sponsored by Cisco Systems, Inc.
- fixed setting unauthenticated attributes (Countersignature, Unauthenticated
  Data Blob) in a nested signature
- added the "-index" option to verify a specific signature or modify its
  unauthenticated attributes
- added CAT file verification
- added listing the contents of a CAT file with the "-verbose" option
- added the new "extract-data" command to extract a PKCS#7 data content to be
  signed with "sign" and attached with "attach-signature"
- added PKCS9_SEQUENCE_NUMBER authenticated attribute support
- added the "-ignore-cdp" option to disable CRL Distribution Points (CDP)
  online verification
- unsuccessful CRL retrieval and verification changed into a critical error
- the "-p" option modified to also use to configured proxy to connect CRL
  Distribution Points
- added implicit allowlisting of the Microsoft Root Authority serial number
  00C1008B3C3C8811D13EF663ECDF40
- added listing of certificate chain retrieved from the signature in case of
  verification failure

### 2.7 (2023.09.19)

- fixed signing CAB files (by Michael Brown)
- fixed handling of unsupported commands (by Maxim Bagryantsev)
- fixed writing DIFAT sectors
- added APPX support (by Maciej Panek and Małgorzata Olszówka)
- added a built-in TSA response generation (-TSA-certs, -TSA-key
  and -TSA-time options)

### 2.6 (2023.05.29)

- modular architecture implemented to simplify adding file formats
- added verification of CRLs specified in the signing certificate
- added MSI DIFAT sectors support (by Max Bagryantsev)
- added legacy provider support for OpenSSL 3.0.0 and later
- fixed numerous bugs

### 2.5 (2022.08.12)

- fixed the Unix executable install path
- fixed the hardcoded "pkcs11" engine id
- fixed building with MinGW
- fixed testing with the python3 distributed with Ubuntu 18.04

### 2.4 (2022.08.02)

- migrated the build system from GNU Autoconf to CMake
- added the "-h" option to set the cryptographic hash function
  for the "attach -signature" and "add" commands
- set the default hash function to "sha256"
- added the "attach-signature" option to compute and compare the
  leaf certificate hash for the "add" command
- renamed the "-st" option "-time" (the old name is accepted for
  compatibility)
- updated the "-time" option to also set explicit verification time
- added the "-ignore-timestamp" option to disable timestamp server
  signature verification
- removed the "-timestamp-expiration" option
- fixed several bugs
- updated the included documentation
- enabled additional compiler/linker hardening options
- added CI based on GitHub Actions

### 2.3 (2022.03.06)

**CRITICAL SECURITY VULNERABILITIES**

This release fixes several critical memory corruption vulnerabilities.
A malicious attacker could create a file, which, when processed with
osslsigncode, triggers arbitrary code execution.  Any previous version
of osslsigncode should be immediately upgraded if the tool is used for
processing of untrusted files.

- fixed several memory safety issues
- fixed non-interactive PVK (MSBLOB) key decryption
- added a bash completion script
- added CA bundle path auto-detection

### 2.2 (2021.08.15)

- CAT files support (thanks to James McKenzie)
- MSI support rewritten without libgsf dependency, which allows
  for handling of all the needed MSI metadata, such as dates
- "-untrusted" option renamed to "-TSA-CAfile"
- "-CRLuntrusted" option renamed to "-TSA-CRLfile"
- numerous bug fixes and improvements

### 2.1 (2020-10-11)

- certificate chain verification support
- timestamp verification support
- CRL verification support ("-CRLfile" option)
- improved CAB signature support
- nested signatures support
- user-specified signing time ("-st" option) by vszakats
- added more tests
- fixed numerous bugs
- dropped OpenSSL 1.1.0 support

### 2.0 (2018-12-04)

- orphaned project adopted by Michał Trojnara
- ported to OpenSSL 1.1.x
- ported to SoftHSM2
- add support for pkcs11-based hardware tokens
  (Patch from Leif Johansson)
- improved error reporting of timestamping errors
  (Patch from Carlo Teubner)

### 1.7.1 (2014-07-11)

- MSI: added -add-msi-dse option
  (Patch from Mikkel Krautz)
- MSI: fix build when GSF_CAN_READ_MSI_METADATA defined
  (Patch from Mikkel Krautz)

### 1.7 (2014-07-10)

- add support for nested signatures
  (Patch from Mikkel Krautz)
- fix compilation problem with OpenSSL < 1.0.0
- added OpenSSL linkage exception to license

### 1.6 (2014-01-21)

- add support for reading password from file
- add support for asking for password (on systems that
  provide support for it)
- add support for compiling and running on Windows
  (Patch from Heiko Hund)
- fix compilation without curl
  (Fix from Heiko Hund)
- added support for giving multiple timestamp servers
  as arguments (first one that succeeds will be used)
- signatures on hierarchical MSI files were broken
  (Fix from Mikkel Krautz)
- MSI: Add support for MsiDigitalSignatureEx signature
  (Patch from Mikkel Krautz)
- add support for adding additional/cross certificates
  through -ac option
  (Thanks to Lars Munch for idea + testing)
- MSI: Add support for signature extract/remove/verify
  (Patches from Mikkel Krautz)
- PE/MSI: Implement -require-leaf-hash for verify.
  (Patch from Mikkel Krautz)

### 1.5.2 (2013-03-13)

- added support for signing with SHA-384 and SHA-512
- added support for page hashing (-ph option)

### 1.5.1 (2013-03-12)

- forgot to bump version number...

### 1.5 (2013-03-12)

- added support for signing MSI files (patch from Marc-André Lureau)
- calculate correct PE checksum instead of setting it to 0
  (patch from Roland Schwingel)
- added support for RFC3161 timestamping (-ts option)
- added support for extracting/removing/verifying signature on PE files
- fixed problem with not being able to decode timestamps with no newlines
- added stricter checks for PE file validity
- added support for reading keys from PVK files (requires OpenSSL 1.0.0 or later)
- added support for reading certificates from PEM files
- renamed program option: -spc to -certs (old option name still valid)

### 1.4 (2011-08-12)

- improved build system (patch from Alon Bar-Lev)
- support reading cert+key from PKCS12 file (patch from Alon Bar-Lev)
- support reading key from PEM file
- added support for sha1/sha256 - default hash is now sha1
- added flag for commercial signing (default is individual)

### 1.3.1 (2009-08-07)

- support signing of 64-bit executables (fix  from Paul Kendall)

### 1.3 (2008-01-31)

- fixed padding problem (fix from Ryan Rubley)
- allow signing of already signed files (fix from Ryan Rubley)
- added Ryan Rubley's PVK-to-DER guide into the README

### 1.2 (2005-01-21)

- autoconf:ed (Thanks to Roy Keene)
- added documentation
- don't override PKCS7_get_signed_attribute, it wasn't
  actually needed, it was me being confused.
- compiles without curl, which means no timestamping
- version number output

### 1.1 (2005-01-19)

- Initial release
