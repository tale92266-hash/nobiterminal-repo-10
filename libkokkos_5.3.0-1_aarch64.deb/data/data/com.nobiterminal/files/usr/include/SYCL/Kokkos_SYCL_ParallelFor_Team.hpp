// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOS_SYCL_PARALLEL_FOR_TEAM_HPP
#define KOKKOS_SYCL_PARALLEL_FOR_TEAM_HPP

#include <Kokkos_Parallel.hpp>

#include <SYCL/Kokkos_SYCL_Team.hpp>
#include <SYCL/Kokkos_SYCL_TeamPolicy.hpp>

#include <sstream>
#include <vector>

template <typename FunctorType, typename... Properties>
class Kokkos::Impl::ParallelFor<FunctorType, Kokkos::TeamPolicy<Properties...>,
                                Kokkos::SYCL> {
 public:
  using Policy       = TeamPolicy<Properties...>;
  using functor_type = FunctorType;
  using size_type    = ::Kokkos::SYCL::size_type;

 private:
  using member_type   = typename Policy::member_type;
  using work_tag      = typename Policy::work_tag;
  using launch_bounds = typename Policy::launch_bounds;

  FunctorType const m_functor;
  Policy const m_policy;
  size_type const m_league_size;
  int m_team_size;
  size_type const m_vector_size;
  int m_shmem_begin;
  int m_shmem_size;
  size_t m_scratch_size[2];

 public:
  static auto create_team_for_lambda(
      const auto& functor_wrapper,
      const sycl::local_accessor<char, 1>& team_scratch_memory_L0,
      const size_t (&scratch_size)[2], const int shmem_begin,
      const sycl::global_ptr<char> global_scratch_ptr) {
    return [=](sycl::nd_item<2> item) {
      const member_type team_member(
          team_scratch_memory_L0.get_multi_ptr<sycl::access::decorated::yes>(),
          shmem_begin, scratch_size[0],
          global_scratch_ptr + item.get_group(1) * scratch_size[1],
          scratch_size[1], item, item.get_group_linear_id(),
          item.get_group_range(1));
      if constexpr (std::is_void_v<work_tag>)
        functor_wrapper.get_functor()(team_member);
      else
        functor_wrapper.get_functor()(work_tag(), team_member);
    };
  }

 private:
  template <typename FunctorWrapper>
  sycl::event sycl_direct_launch(
      const sycl::global_ptr<char> global_scratch_ptr,
      const FunctorWrapper& functor_wrapper,
      const sycl::event& memcpy_event) const {
    // Convenience references
    const Kokkos::SYCL& space = m_policy.space();
    sycl::queue& q            = space.sycl_queue();

    desul::ensure_sycl_lock_arrays_on_device(q);

    auto cgh_lambda = [&](sycl::handler& cgh) {
      // FIXME_SYCL accessors seem to need a size greater than zero at least for
      // host queues
      sycl::local_accessor<char, 1> team_scratch_memory_L0(
          sycl::range<1>(
              std::max(m_scratch_size[0] + m_shmem_begin, size_t(1))),
          cgh);

      // Avoid capturing *this since it might not be trivially copyable
      const auto shmem_begin       = m_shmem_begin;
      const size_t scratch_size[2] = {m_scratch_size[0], m_scratch_size[1]};

      auto lambda =
          create_team_for_lambda(functor_wrapper, team_scratch_memory_L0,
                                 scratch_size, shmem_begin, global_scratch_ptr);

      static sycl::kernel kernel = [&] {
        sycl::kernel_id functor_kernel_id =
            sycl::get_kernel_id<decltype(lambda)>();
        auto kernel_bundle =
            sycl::get_kernel_bundle<sycl::bundle_state::executable>(
                q.get_context(), std::vector{functor_kernel_id});
        return kernel_bundle.get_kernel(functor_kernel_id);
      }();
      auto max_sg_size =
          kernel
              .get_info<sycl::info::kernel_device_specific::max_sub_group_size>(
                  q.get_device());
      auto final_vector_size = std::min<int>(m_vector_size, max_sg_size);
      // FIXME_SYCL For some reason, explicitly enforcing the kernel bundle to
      // be used gives a runtime error.
      // cgh.use_kernel_bundle(kernel_bundle);

#ifndef KOKKOS_IMPL_SYCL_USE_IN_ORDER_QUEUES
      cgh.depends_on(memcpy_event);
#else
      (void)memcpy_event;
#endif
      cgh.parallel_for(
          sycl::nd_range<2>(
              sycl::range<2>(m_team_size, static_cast<size_t>(m_league_size) *
                                              final_vector_size),
              sycl::range<2>(m_team_size, final_vector_size)),
          lambda);
    };

#ifdef KOKKOS_IMPL_SYCL_GRAPH_SUPPORT
    if constexpr (Policy::is_graph_kernel::value) {
      sycl_attach_kernel_to_node(*this, cgh_lambda);
      return {};
    } else
#endif
    {
      auto parallel_for_event = q.submit(cgh_lambda);

#ifndef KOKKOS_IMPL_SYCL_USE_IN_ORDER_QUEUES
      q.ext_oneapi_submit_barrier(std::vector<sycl::event>{parallel_for_event});
#endif
      return parallel_for_event;
    }
  }

 public:
  inline void execute() const {
    if (m_league_size == 0) return;

    auto& instance = *m_policy.space().impl_internal_space_instance();

    // Functor's reduce memory, team scan memory, and team shared memory depend
    // upon team size.
    int scratch_pool_id = instance.acquire_team_scratch_space();
    const sycl::global_ptr<char> global_scratch_ptr =
        static_cast<sycl::global_ptr<char>>(instance.resize_team_scratch_space(
            scratch_pool_id,
            static_cast<ptrdiff_t>(m_scratch_size[1]) * m_league_size));

    Kokkos::Impl::SYCLInternal::IndirectKernelMem& indirectKernelMem =
        instance.get_indirect_kernel_mem();

    auto functor_wrapper =
        Impl::make_sycl_function_wrapper(m_functor, indirectKernelMem);

    sycl::event event = sycl_direct_launch(global_scratch_ptr, functor_wrapper,
                                           functor_wrapper.get_copy_event());
    functor_wrapper.register_event(event);
    instance.release_team_scratch_space(scratch_pool_id);
  }

  ParallelFor(FunctorType const& arg_functor, Policy const& arg_policy)
      : m_functor(arg_functor),
        m_policy(arg_policy),
        m_league_size(m_policy.league_size()),
        m_team_size(m_policy.team_size()),
        m_vector_size(m_policy.impl_vector_length()) {
    if (m_team_size < 0) {
      m_team_size = m_policy.team_size_recommended(m_functor, ParallelForTag{});
      if (m_team_size <= 0)
        Kokkos::Impl::throw_runtime_exception(
            "Kokkos::Impl::ParallelFor<SYCL, TeamPolicy> could not find a "
            "valid execution configuration.");
    }

    m_shmem_begin = (sizeof(double) * (m_team_size + 2));
    m_shmem_size =
        (m_policy.scratch_size(0, m_team_size) +
         FunctorTeamShmemSize<FunctorType>::value(m_functor, m_team_size));
    m_scratch_size[0] = m_shmem_size;
    m_scratch_size[1] = m_policy.scratch_size(1, m_team_size);

    const auto& instance = *m_policy.space().impl_internal_space_instance();
    if (static_cast<int>(instance.m_maxShmemPerBlock) <
        m_shmem_size + m_shmem_begin) {
      std::stringstream out;
      out << "Kokkos::parallel_for<SYCL> Requested too much scratch memory on "
             "level 0. Requested: "
          << m_shmem_size + m_shmem_begin
          << ", Maximum: " << instance.m_maxShmemPerBlock;
      Kokkos::Impl::throw_runtime_exception(out.str());
    }

    if (m_scratch_size[1] > static_cast<size_t>(m_policy.scratch_size_max(1))) {
      std::stringstream out;
      out << "Kokkos::parallel_for<SYCL> Requested too much scratch memory on "
             "level 1. Requested: "
          << m_scratch_size[1] << ", Maximum: " << m_policy.scratch_size_max(1);
      Kokkos::Impl::throw_runtime_exception(out.str());
    }

    const auto max_team_size =
        m_policy.team_size_max(arg_functor, ParallelForTag{});
    if (m_team_size > max_team_size) {
      std::stringstream error;
      error << "Kokkos::parallel_for<SYCL>: Requested too large team size. "
               "Requested: "
            << m_team_size << ", Maximum: " << max_team_size;
      Kokkos::Impl::throw_runtime_exception(error.str().c_str());
    }
  }
};

#endif
