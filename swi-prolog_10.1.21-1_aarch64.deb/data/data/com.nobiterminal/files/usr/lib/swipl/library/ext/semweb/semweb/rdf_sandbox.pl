/*  Part of SWI-Prolog

    Author:        Jan Wielemaker
    E-mail:        J.Wielemaker@vu.nl
    WWW:           http://www.swi-prolog.org
    Copyright (c)  2016, VU University Amsterdam
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:

    1. Redistributions of source code must retain the above copyright
       notice, this list of conditions and the following disclaimer.

    2. Redistributions in binary form must reproduce the above copyright
       notice, this list of conditions and the following disclaimer in
       the documentation and/or other materials provided with the
       distribution.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
    FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
    COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
    LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
    ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
    POSSIBILITY OF SUCH DAMAGE.
*/

:- module(rdf_sandbox, []).
:- autoload(library(error),
            [ instantiation_error/1, type_error/2, permission_error/3,
              must_be/2
            ]).
:- autoload(library(lists), [member/2, append/3]).

/** <module> Declare RDF API sandbox-safe

This   module   provides   clauses   for     the   multifile   predicate
sandbox:safe_primitive/1  defined  in  library(sandbox)  that  make  all
predicates of the RDF API that have   no permanent side effects safe. To
have an affect, this  module  must  be   *loaded  after  the  modules it
declares safe*. Thus, when using the   sequence  below, `rdf11` is safe,
while `sparql_client` is not (unless   sparql_client  was already loaded
before this sequence).

  ```
  :- use_module(library(semweb/rdf11)).         % safe
  :- use_module(library(semweb/rdf_sandbox)).
  :- use_module(library(semweb/sparql_client)). % Not safe
  ```

Normally, sandbox declarations live in  the   module  in  which the safe
predicates are defined, so we are sure  we are making declarations about
this specific version of a predicate. For   RDF we decoupled the sandbox
declarations  from  the  implementation  because    although   rdf/3  is
technically safe to use (calling it has   no side effects), it may _make
information accessible_ that is not supposed to be.

Loading this library makes all   side-effect-free  predicates considered
safe. If some of your RDF needs to  remain hidden, you should *not* load
this file and instead use your own   version that project your data. The
example below defines a wrapper around   rdf/4 that provides safe access
to certain graphs.

``` :- module(rdf_api,
          [ rdf/4
          ]).
:- use_module(library(semweb/rdf11)).

:- rdf_meta rdf(r,r,o,r).

rdf(S,P,O,G) :-
        public_graph(G), !,
        rdf11:rdf(S,P,O,G).
rdf(S,P,O,G) :-
        permission_error(access, graph, G).

:- multifile sandbox:safe_primitive/1.

sandbox:safe_primitive(rdf_api:rdf(_,_,_,_)).
*/

:- multifile
    sandbox:safe_primitive/1,
    sandbox:safe_meta_predicate/1.


                 /*******************************
                 *             RDF_DB           *
                 *******************************/

:- if(current_predicate(rdf_db:rdf/3)).
sandbox:safe_primitive(rdf_db:rdf(_,_,_)).
sandbox:safe_primitive(rdf_db:rdf(_,_,_,_)).
sandbox:safe_primitive(rdf_db:rdf_has(_,_,_)).
sandbox:safe_primitive(rdf_db:rdf_has(_,_,_,_)).
sandbox:safe_primitive(rdf_db:rdf_reachable(_,_,_)).
sandbox:safe_primitive(rdf_db:rdf_reachable(_,_,_,_,_)).
sandbox:safe_primitive(rdf_db:rdf_resource(_)).
sandbox:safe_primitive(rdf_db:rdf_subject(_)).
sandbox:safe_primitive(rdf_db:rdf_predicate_property(_,_)).
sandbox:safe_primitive(rdf_db:rdf_current_predicate(_)).
sandbox:safe_primitive(rdf_db:rdf_current_literal(_)).
sandbox:safe_primitive(rdf_db:rdf_graph(_)).
sandbox:safe_primitive(rdf_db:rdf_generation(_)).
sandbox:safe_primitive(rdf_db:rdf_estimate_complexity(_,_,_,_)).
sandbox:safe_primitive(rdf_db:rdf_statistics(_)).
sandbox:safe_primitive(rdf_db:lang_matches(_,_)).
sandbox:safe_primitive(rdf_db:lang_equal(_,_)).
sandbox:safe_primitive(rdf_db:rdf_version(_)).
sandbox:safe_primitive(rdf_db:rdf_md5(_,_)).
sandbox:safe_primitive(rdf_db:rdf_graph_modified_(_,_,_)).
sandbox:safe_primitive(rdf_db:rdf_graph_source_(_,_,_)).
sandbox:safe_primitive(rdf_db:rdf_graph_(_,_)).
sandbox:safe_primitive(rdf_db:rdf_find_literal_map(_,_,_)).
sandbox:safe_primitive(rdf_db:rdf_keys_in_literal_map(_,_,_)).
sandbox:safe_primitive(rdf_db:rdf_statistics_literal_map(_,_)).

sandbox:safe_meta_predicate(rdf_prefixes:rdf_current_prefix/2).
sandbox:safe_meta_predicate(rdf_prefixes:rdf_global_id/2).
:- endif.


                 /*******************************
                 *            RDF11             *
                 *******************************/

:- if(current_predicate(rdf11:in_xml_literal/3)).
sandbox:safe_primitive(rdf11:in_xml_literal(_,_,_)).
sandbox:safe_primitive(rdf11:pre_object(_,_,_,_)).
sandbox:safe_primitive(rdf11:post_object(_,_)).
sandbox:safe_primitive(rdf11:rdf_where(_)).
:- endif.


                 /*******************************
                 *         RDF-LITINDEX         *
                 *******************************/

:- if(current_predicate(rdf_litindex:rdf_find_literals/2)).
sandbox:safe_primitive(rdf_litindex:rdf_find_literals(_,_)).
sandbox:safe_primitive(rdf_litindex:rdf_tokenize_literal(_,_)).
sandbox:safe_primitive(rdf_litindex:rdf_literal_index(_,_)).
:- endif.

                 /*******************************
                 *         SPARQL-CLIENT        *
                 *******************************/

:- if(current_predicate(sparql_client:sparql_query/3)).
sandbox:safe_meta(sparql_client:sparql_query(_,_,Options), Calls) :-
    safe_sparql_options(Options, Calls).
:- endif.

%!  safe_sparql_options(+Options, -Calls) is det.
%
%   Only allow for options of sparql_query/3 that do not access local
%   resources such as files.  The options are passed to http_open/3
%   and ssl_context/3.  SSL hooks are verified as meta-calls.

safe_sparql_options(Options, _) :-
    var(Options),
    !,
    instantiation_error(Options).
safe_sparql_options([], []) :-
    !.
safe_sparql_options([H|T], Calls) :-
    !,
    safe_sparql_option(H, Calls, Calls1),
    safe_sparql_options(T, Calls1).
safe_sparql_options(Options, _) :-
    type_error(list, Options).

safe_sparql_option(Opt, _, _) :-
    var(Opt),
    !,
    instantiation_error(Opt).
safe_sparql_option(Name = Value, Calls0, Calls) :-
    !,
    (   atom(Name)
    ->  Opt =.. [Name,Value],
        safe_sparql_option(Opt, Calls0, Calls)
    ;   instantiation_error(Name)
    ).
safe_sparql_option(cacerts(List), Calls, Calls) :-
    !,
    must_be(list, List),
    (   member(E, List),
        \+ safe_cacert(E)
    ->  permission_error(use, option, cacerts(List))
    ;   true
    ).
safe_sparql_option(Opt, [Call|Calls], Calls) :-
    hook_option(Opt, Goal, Arity),
    !,
    hook_call(Goal, Arity, Call).
safe_sparql_option(Opt, Calls, Calls) :-
    compound(Opt),
    compound_name_arity(Opt, Name, 1),
    safe_sparql_option_name(Name),
    !.
safe_sparql_option(Opt, _, _) :-
    permission_error(use, option, Opt).

safe_cacert(E) :-
    var(E),
    !,
    instantiation_error(E).
safe_cacert(system(root_certificates)).
safe_cacert(certificate(_)).

% sparql_query/3 options
safe_sparql_option_name(endpoint).
safe_sparql_option_name(scheme).
safe_sparql_option_name(host).
safe_sparql_option_name(port).
safe_sparql_option_name(path).
safe_sparql_option_name(search).
safe_sparql_option_name(query_string).
safe_sparql_option_name(variable_names).
safe_sparql_option_name(user).
safe_sparql_option_name(password).
% http_open/3 options
safe_sparql_option_name(timeout).
safe_sparql_option_name(connection_timeout).
safe_sparql_option_name(user_agent).
safe_sparql_option_name(authorization).
safe_sparql_option_name(request_header).
safe_sparql_option_name(proxy).
safe_sparql_option_name(proxy_authorization).
% ssl_context/3 options that do not access files
safe_sparql_option_name(certificate_key_pairs).
safe_sparql_option_name(require_crl).
safe_sparql_option_name(cipher_list).
safe_sparql_option_name(ecdh_curve).
safe_sparql_option_name(min_protocol_version).
safe_sparql_option_name(max_protocol_version).
safe_sparql_option_name(disable_ssl_methods).

hook_option(cert_verify_hook(Goal),  Goal, 5).
hook_option(pem_password_hook(Goal), Goal, 2).

%   SSL hooks that are not module qualified are called in the module
%   http_ssl_plugin.

hook_call(Goal, _, _) :-
    var(Goal),
    !,
    instantiation_error(Goal).
hook_call(M:Goal, Arity, M:Call) :-
    !,
    must_be(callable, Goal),
    length(Extra, Arity),
    extend(Goal, Extra, Call).
hook_call(Goal, Arity, Call) :-
    must_be(callable, Goal),
    length(Extra, Arity),
    extend(Goal, Extra, Plain),
    (   predicate_property(http_ssl_plugin:Plain, imported_from(M))
    ->  Call = M:Plain
    ;   Call = http_ssl_plugin:Plain
    ).

extend(Goal, Extra, Call) :-
    Goal =.. List0,
    append(List0, Extra, List),
    Call =.. List.
