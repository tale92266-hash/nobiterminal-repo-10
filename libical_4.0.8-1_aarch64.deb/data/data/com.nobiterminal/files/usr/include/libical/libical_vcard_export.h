
#ifndef LIBICAL_VCARD_EXPORT_H
#define LIBICAL_VCARD_EXPORT_H

#ifdef LIBICAL_VCARD_STATIC_DEFINE
#  define LIBICAL_VCARD_EXPORT
#  define LIBICAL_VCARD_NO_EXPORT
#else
#  ifndef LIBICAL_VCARD_EXPORT
#    ifdef icalvcard_EXPORTS
        /* We are building this library */
#      define LIBICAL_VCARD_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define LIBICAL_VCARD_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef LIBICAL_VCARD_NO_EXPORT
#    define LIBICAL_VCARD_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef LIBICAL_VCARD_DEPRECATED
#  define LIBICAL_VCARD_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef LIBICAL_VCARD_DEPRECATED_EXPORT
#  define LIBICAL_VCARD_DEPRECATED_EXPORT LIBICAL_VCARD_EXPORT LIBICAL_VCARD_DEPRECATED
#endif

#ifndef LIBICAL_VCARD_DEPRECATED_NO_EXPORT
#  define LIBICAL_VCARD_DEPRECATED_NO_EXPORT LIBICAL_VCARD_NO_EXPORT LIBICAL_VCARD_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef LIBICAL_VCARD_NO_DEPRECATED
#    define LIBICAL_VCARD_NO_DEPRECATED
#  endif
#endif

#endif /* LIBICAL_VCARD_EXPORT_H */
