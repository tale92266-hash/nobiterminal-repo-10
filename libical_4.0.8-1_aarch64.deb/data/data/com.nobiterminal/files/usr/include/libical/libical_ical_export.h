
#ifndef LIBICAL_ICAL_EXPORT_H
#define LIBICAL_ICAL_EXPORT_H

#ifdef LIBICAL_ICAL_STATIC_DEFINE
#  define LIBICAL_ICAL_EXPORT
#  define LIBICAL_ICAL_NO_EXPORT
#else
#  ifndef LIBICAL_ICAL_EXPORT
#    ifdef ical_EXPORTS
        /* We are building this library */
#      define LIBICAL_ICAL_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define LIBICAL_ICAL_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef LIBICAL_ICAL_NO_EXPORT
#    define LIBICAL_ICAL_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef LIBICAL_ICAL_DEPRECATED
#  define LIBICAL_ICAL_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef LIBICAL_ICAL_DEPRECATED_EXPORT
#  define LIBICAL_ICAL_DEPRECATED_EXPORT LIBICAL_ICAL_EXPORT LIBICAL_ICAL_DEPRECATED
#endif

#ifndef LIBICAL_ICAL_DEPRECATED_NO_EXPORT
#  define LIBICAL_ICAL_DEPRECATED_NO_EXPORT LIBICAL_ICAL_NO_EXPORT LIBICAL_ICAL_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef LIBICAL_ICAL_NO_DEPRECATED
#    define LIBICAL_ICAL_NO_DEPRECATED
#  endif
#endif

#endif /* LIBICAL_ICAL_EXPORT_H */
