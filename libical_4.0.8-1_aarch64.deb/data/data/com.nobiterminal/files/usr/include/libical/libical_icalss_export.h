
#ifndef LIBICAL_ICALSS_EXPORT_H
#define LIBICAL_ICALSS_EXPORT_H

#ifdef LIBICAL_ICALSS_STATIC_DEFINE
#  define LIBICAL_ICALSS_EXPORT
#  define LIBICAL_ICALSS_NO_EXPORT
#else
#  ifndef LIBICAL_ICALSS_EXPORT
#    ifdef icalss_EXPORTS
        /* We are building this library */
#      define LIBICAL_ICALSS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define LIBICAL_ICALSS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef LIBICAL_ICALSS_NO_EXPORT
#    define LIBICAL_ICALSS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef LIBICAL_ICALSS_DEPRECATED
#  define LIBICAL_ICALSS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef LIBICAL_ICALSS_DEPRECATED_EXPORT
#  define LIBICAL_ICALSS_DEPRECATED_EXPORT LIBICAL_ICALSS_EXPORT LIBICAL_ICALSS_DEPRECATED
#endif

#ifndef LIBICAL_ICALSS_DEPRECATED_NO_EXPORT
#  define LIBICAL_ICALSS_DEPRECATED_NO_EXPORT LIBICAL_ICALSS_NO_EXPORT LIBICAL_ICALSS_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef LIBICAL_ICALSS_NO_DEPRECATED
#    define LIBICAL_ICALSS_NO_DEPRECATED
#  endif
#endif

#endif /* LIBICAL_ICALSS_EXPORT_H */
