
#ifndef LIBICAL_VCAL_EXPORT_H
#define LIBICAL_VCAL_EXPORT_H

#ifdef LIBICAL_VCAL_STATIC_DEFINE
#  define LIBICAL_VCAL_EXPORT
#  define LIBICAL_VCAL_NO_EXPORT
#else
#  ifndef LIBICAL_VCAL_EXPORT
#    ifdef icalvcal_EXPORTS
        /* We are building this library */
#      define LIBICAL_VCAL_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define LIBICAL_VCAL_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef LIBICAL_VCAL_NO_EXPORT
#    define LIBICAL_VCAL_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef LIBICAL_VCAL_DEPRECATED
#  define LIBICAL_VCAL_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef LIBICAL_VCAL_DEPRECATED_EXPORT
#  define LIBICAL_VCAL_DEPRECATED_EXPORT LIBICAL_VCAL_EXPORT LIBICAL_VCAL_DEPRECATED
#endif

#ifndef LIBICAL_VCAL_DEPRECATED_NO_EXPORT
#  define LIBICAL_VCAL_DEPRECATED_NO_EXPORT LIBICAL_VCAL_NO_EXPORT LIBICAL_VCAL_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef LIBICAL_VCAL_NO_DEPRECATED
#    define LIBICAL_VCAL_NO_DEPRECATED
#  endif
#endif

#endif /* LIBICAL_VCAL_EXPORT_H */
