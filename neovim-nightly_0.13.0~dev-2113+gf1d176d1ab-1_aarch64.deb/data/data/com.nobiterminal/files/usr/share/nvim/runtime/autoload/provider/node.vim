if exists('g:loaded_node_provider')
  finish
endif
let g:loaded_node_provider = 0

function! s:is_minimum_version(version, min_version) abort
  if empty(a:version)
    let nodejs_version = get(split(system(['node', '-v']), "\n"), 0, '')
    if v:shell_error || nodejs_version[0] !=# 'v'
      return 0
    endif
  else
    let nodejs_version = a:version
  endif
  " Remove surrounding junk.  Example: 'v4.12.0' => '4.12.0'
  let nodejs_version = matchstr(nodejs_version, '\(\d\.\?\)\+')
  " [major, minor, patch]
  return !v:lua.vim.version.lt(nodejs_version, a:min_version)
endfunction

let s:NodeHandler = {
\ 'stdout_buffered': v:true,
\ 'result': ''
\ }
function! s:NodeHandler.on_exit(job_id, data, event) abort
  let bin_dir = join(get(self, 'stdout', []), '')
  let entry_point = bin_dir . self.entry_point
  let self.result = filereadable(entry_point) ? entry_point : ''
endfunction

" Support for --inspect-brk requires node 6.12+ or 7.6+ or 8+
" Return 1 if it is supported
" Return 0 otherwise
function! provider#node#can_inspect() abort
  if !executable('node')
    return 0
  endif
  let ver = get(split(system(['node', '-v']), "\n"), 0, '')
  if v:shell_error || ver[0] !=# 'v'
    return 0
  endif
  return (ver[1] ==# '6' && s:is_minimum_version(ver, '6.12.0'))
    \ || s:is_minimum_version(ver, '7.6.0')
endfunction

function! provider#node#Detect() abort
  let minver = '6.0.0'
  if exists('g:node_host_prog')
    return [expand(g:node_host_prog, v:true), '']
  endif
  if !executable('node')
    return ['', 'node not found (or not executable)']
  endif
  if !s:is_minimum_version(v:null, minver)
    return ['', printf('node version %s not found', minver)]
  endif

  let npm_opts = {}
  if executable('npm')
    let npm_opts = deepcopy(s:NodeHandler)
    let npm_opts.entry_point = '/neovim/bin/cli.js'
    let npm_opts.job_id = jobstart('npm --loglevel silent root -g', npm_opts)
  endif

  let yarn_opts = {}
  if executable('yarn')
    let yarn_opts = deepcopy(s:NodeHandler)
    let yarn_opts.entry_point = '/node_modules/neovim/bin/cli.js'
    " `yarn global dir` is slow (> 250ms), try the default path first
    " https://github.com/yarnpkg/yarn/issues/2049#issuecomment-263183768
    let yarn_config_dir = has('win32') ? '/AppData/Local/Yarn/Data' : '/.config/yarn'
    let yarn_default_path = $HOME . yarn_config_dir . '/global/' . yarn_opts.entry_point
    if filereadable(yarn_default_path)
      return [yarn_default_path, '']
    endif
    let yarn_opts.job_id = jobstart('yarn global dir', yarn_opts)
  endif

  let pnpm_opts = {}
  if executable('pnpm')
    let pnpm_opts = deepcopy(s:NodeHandler)
    let pnpm_opts.entry_point = '/neovim/bin/cli.js'
    let pnpm_opts.job_id = jobstart('pnpm --loglevel silent root -g', pnpm_opts)
  endif

  if executable('bun')
    let bun_bin_dir = trim(system(['bun', 'pm', 'bin', '-g']))
    if v:shell_error == 0 && !empty(bun_bin_dir)
      if has('win32')
        "On Windows Node.js cannot execute the .cmd shims created by Bun.
        let bun_root_dir = fnamemodify(bun_bin_dir, ':h')
        let bun_default_path = bun_root_dir . '/install/global/node_modules/neovim/bin/cli.js'
      else
        let bun_default_path = bun_bin_dir . '/neovim-node-host'
      endif
      if filereadable(bun_default_path)
        return [bun_default_path, '']
      endif
    endif
  endif

  " npm returns the directory faster, so let's check that first
  if !empty(npm_opts)
    let result = jobwait([npm_opts.job_id])
    if result[0] == 0 && npm_opts.result != ''
      return [npm_opts.result, '']
    endif
  endif

  if !empty(yarn_opts)
    let result = jobwait([yarn_opts.job_id])
    if result[0] == 0 && yarn_opts.result != ''
      return [yarn_opts.result, '']
    endif
  endif

  if !empty(pnpm_opts)
    let result = jobwait([pnpm_opts.job_id])
    if result[0] == 0 && pnpm_opts.result != ''
      return [pnpm_opts.result, '']
    endif
  endif

  return ['', 'failed to detect node']
endfunction

function! provider#node#Prog() abort
  return s:prog
endfunction

function! provider#node#Require(host) abort
  if s:err != ''
    echoerr s:err
    return
  endif

  let args = ['node']

  if !empty($NVIM_NODE_HOST_DEBUG) && provider#node#can_inspect()
    call add(args, '--inspect-brk')
  endif

  call add(args, provider#node#Prog())

  return provider#Poll(args, a:host.orig_name, '$NVIM_NODE_LOG_FILE')
endfunction

function! provider#node#Call(method, args) abort
  if s:err != ''
    echoerr s:err
    return
  endif

  if !exists('s:host')
    try
      let s:host = remote#host#Require('node')
    catch
      let s:err = v:exception
      echohl WarningMsg
      echomsg v:exception
      echohl None
      return
    endtry
  endif
  return call('rpcrequest', insert(insert(a:args, 'node_'.a:method), s:host))
endfunction


let s:err = ''
let [s:prog, s:_] = provider#node#Detect()
let g:loaded_node_provider = empty(s:prog) ? 0 : 2

if g:loaded_node_provider != 2
  let s:err = 'Cannot find the "neovim" node package. Try :checkhealth'
endif

call remote#host#RegisterPlugin('node-provider', 'node', [])
