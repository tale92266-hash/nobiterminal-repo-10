/// <reference path="./lib/fresh.d.ts" />
import {
  button,
  col,
  flexSpacer,
  FloatingWidgetPanel,
  hintBar,
  key as widgetKey,
  label,
  parseHintString,
  raw,
  row,
  spacer,
  type StyledSegment,
  styledRow,
  textInput,
  textInputChar,
  toggle,
  tree,
  treeNode,
  type TreeNode,
  type WidgetAction,
  WidgetPanel,
  type WidgetSpec,
  wrappingRow,
} from "./lib/widgets.ts";

const editor = getEditor();

/**
 * Multi-File Search & Replace Plugin
 *
 * Compact two-line control bar + hierarchical match tree.
 * Direct inline editing of search/replace fields (no prompts).
 * Navigation uses state-managed selectedIndex (like theme_editor).
 */

// =============================================================================
// Types
// =============================================================================

interface SearchResult {
  match: GrepMatch;
  selected: boolean;
  // Interval-marker anchor (issue #2583). For a match whose file is open we
  // register a marker at its byte range; the editor keeps it shifted across
  // every edit kind — including bulk paste / multi-cursor / type-over-
  // selection / query-replace / LSP code-action rewrites that apply as a
  // single BulkEdit and bypass the after_insert/after_delete hooks. These
  // hold the key + buffer so we can read the live position back and delete
  // the marker later. Absent for matches in files that aren't open (those
  // can't be edited, so the grep position stays valid as a fallback).
  markerKey?: string;
  markerBufferId?: number;
}

interface FileGroup {
  relPath: string;
  absPath: string;
  expanded: boolean;
  matches: SearchResult[];
}

type FocusPanel = "query" | "options" | "matches";
type QueryField = "search" | "replace";

interface PanelState {
  /** The window the panel lives in. Its buffer and splits belong to that
   *  window, and split ids mean nothing outside it (#3704). */
  windowId: number;
  /** The panel's window's root, for project-relative paths. Kept because
   *  `getCwd()` answers for the active window, which a search running in
   *  the background is not. */
  root: string;
  /** Its results are out of date: a re-search was asked for, or a replace
   *  finished, while the panel's window was in the background. Re-searched
   *  when the window is active again. */
  stale: boolean;
  /** The deferred re-search was an edit's, which keeps the user's place in
   *  the results (`rerunSearch(keepPosition)`). */
  staleKeepPosition: boolean;
  /** A search finished or progressed while the panel's window was in the
   *  background, where nothing is drawn: draw it when the window is back. */
  needsRedraw: boolean;
  /** Incremented on each new search of this panel to discard stale results.
   *  Per panel, so a search in one window never cancels another's. */
  searchGeneration: number;
  /** This panel's in-flight search, kept so a superseding one can cancel it. */
  searchHandle: SearchHandle | null;
  /** Debounce generation for re-searches of this panel: a newer request
   *  drops an older pending one, but never another window's. */
  debounceGeneration: number;
  /** The re-search an edit started, while it runs. It empties the result
   *  set until the new one lands and then puts the selection back, so a step
   *  pressed meanwhile waits for it instead of being dropped as "Searching…". */
  searchAfterEdit: Promise<void> | null;
  /** Lock against re-entrant Replace All / Replace Scoped on this panel. */
  replaceInProgress: boolean;
  /** A status message for this panel's window, held while it was in the
   *  background (status messages are per window) and shown on return. */
  pendingStatus: string | null;
  /** The per-window context the module-level `resumeAnchor` and
   *  `lastReplacedFiles` hold for the active panel, parked here while the
   *  panel's window is in the background. */
  parked: { resumeAnchor: ResumeAnchor | null; replacedFiles: Set<string> } | null;
  resultsBufferId: number;
  sourceSplitId: number;
  resultsSplitId: number;
  searchResults: SearchResult[];
  fileGroups: FileGroup[];
  searchPattern: string;
  replaceText: string;
  // Optional comma-separated file globs. Basename patterns such as `*.ts`
  // match at any depth; path patterns such as `src/**` match paths relative
  // to the workspace root.
  fileGlob: string;
  // Navigation
  focusPanel: FocusPanel;
  queryField: QueryField;
  optionIndex: number;
  matchIndex: number;
  // Options
  caseSensitive: boolean;
  useRegex: boolean;
  wholeWords: boolean;
  // Scope (§1): when false, results are restricted to the source buffer.
  // `sourceBufferPath` is the absolute path of the buffer that was
  // active when the panel opened; `sourceBufferRelPath` is the
  // cwd-relative display form. An empty path means the source buffer is
  // unnamed/unsaved — in that case scope filtering falls back to
  // `sourceBufferId`, and the host searches that buffer's in-memory
  // content directly (it has no on-disk file the project walk can find).
  allFiles: boolean;
  sourceBufferPath: string;
  sourceBufferRelPath: string;
  // Buffer id of the source buffer, used to scope/replace unnamed buffers
  // by id when there's no path to match on. 0 means "unknown".
  sourceBufferId: number;
  // Layout
  viewportWidth: number;
  // State
  busy: boolean;
  /** True once the current `searchPattern` has been used to run a real
   * search to completion. Reset whenever the pattern is mutated (or a
   * search-affecting toggle changes). Distinguishes "user is typing,
   * no search has happened" from "search ran and found nothing", so we
   * don't show a misleading "No matches" placeholder before any work
   * has been done. See §17 of
   * `docs/internal/search-replace-scope-replan-on-widgets.md`. */
  searchPerformed: boolean;
  truncated: boolean;
  // Inline editing cursor position
  cursorPos: number;
  // Virtual scroll offset for matches tree
  scrollOffset: number;
  // Per-file expansion state mirrored from the Tree widget's host
  // instance state. The widget owns expansion (host re-renders on
  // disclosure click / Right / Left without the plugin reacting);
  // this set is only read by the plugin's `activate` handler so
  // Enter on a file row can toggle expansion via
  // `panel.setExpandedKeys`. Both sets are cleared at the start of
  // every fresh search.
  expandedFileKeys: Set<string>;
  // Memo of file-row keys we've already seen during the current
  // search. Used by `buildMatchListSpec` to auto-expand newly-
  // discovered files (default = expanded) without overriding user
  // collapse state on previously-seen files.
  knownFileKeys: Set<string>;
  // Widget panel handle. The panel mounts a `Col[Raw{body}, HintBar{hints}]`
  // spec — the body keeps the existing hand-rolled rendering for now,
  // and the footer is built by the host's HintBar widget so its keys are
  // styled consistently with every other plugin's footer (theme-keyed
  // `ui.help_key_fg`). Subsequent migration passes will pull the
  // search/replace inputs, the toggles, and the match tree out of
  // `Raw` and into typed widgets. See
  // `docs/internal/plugin-widget-library-design.md` §10.
  widgetPanel: WidgetPanel | null;
}
/** Each window's panel, by window id. A window has its own panel — query,
 *  results, selection and scroll — and switching windows leaves the other
 *  windows' panels as they were (#3704). */
const panels = new Map<number, PanelState>();
/** Run `fn` with `panel` pointing at `p`. The view builders read the
 *  module-level `panel`; a search runs for the panel it started in, which
 *  may no longer be the active one. Synchronous, so nothing else can observe
 *  the swap. */
function withPanel<T>(p: PanelState, fn: () => T): T {
  const saved = panel;
  panel = p;
  try {
    return fn();
  } finally {
    panel = saved;
  }
}

/** A window's open buffers, by path. Per window (`listBuffers(windowId)`),
 *  never the active one's: buffer ids are unique editor-wide, but two
 *  windows can each hold a buffer of the same file. */
function windowBuffersByPath(windowId: number): Map<string, number> {
  const byPath = new Map<string, number>();
  for (const b of editor.listBuffers(windowId)) {
    if (b.path) byPath.set(b.path, b.id);
  }
  return byPath;
}

/** The window the user is in, kept current by `active_window_changed`. */
let currentWindowId = editor.activeWindow();
/** The active window's panel: `panels.get(currentWindowId)`, kept as a
 *  variable because everything that handles input reads it. Only this panel
 *  is ever searched or drawn — the host searches and paints the active
 *  window. */
let panel: PanelState | null = null;

/** The match options the *next* panel opens on.
 *
 * The panel itself is rebuilt from scratch every time it opens, so
 * without this the Case / Regex / Word toggles reset on each open and
 * a user who wants case-sensitive matching has to say so again every
 * single time. Seeded from the `editor.search` config preset, then
 * updated by every toggle — so the last state wins for the rest of the
 * session, and the config decides only where the session starts.
 *
 * Session-scoped on purpose: the config file is not rewritten behind
 * the user's back, and the in-buffer search prompt persists its own
 * copy with the workspace.
 */
const sessionMatchOptions = {
  caseSensitive: false,
  useRegex: false,
  wholeWords: false,
};

/** Seed `sessionMatchOptions` from `editor.search`. Anything missing or
 *  non-boolean stays off, which is also the shipped default. */
function seedMatchOptionsFromConfig(): void {
  const search = (
    editor.getConfig() as
      | {
          editor?: {
            search?: {
              case_sensitive?: unknown;
              regex?: unknown;
              whole_word?: unknown;
            };
          };
        }
      | null
  )?.editor?.search;
  sessionMatchOptions.caseSensitive = search?.case_sensitive === true;
  sessionMatchOptions.useRegex = search?.regex === true;
  sessionMatchOptions.wholeWords = search?.whole_word === true;
}
seedMatchOptionsFromConfig();

const MAX_RESULTS = 10000;
const MIN_WIDTH = 60;
const DEFAULT_WIDTH = 100;
const SEARCH_DEBOUNCE_MS = 150;


/** Most-recent-first history of search patterns, capped at HISTORY_MAX.
 *  Up arrow in the search field walks back into older entries; Down
 *  walks forward. Persistence across editor restarts is a follow-up.
 *  See §11 of docs/internal/search-replace-scope-replan-on-widgets.md. */
const searchHistory: string[] = [];
const HISTORY_MAX = 20;
/** -1 = not navigating history. 0..searchHistory.length-1 = currently
 *  displaying the history entry at that index. */
let historyIndex = -1;
/** Whatever the user had in the search field before they pressed Up
 *  to enter history-walk mode. Restored when they Down past the most
 *  recent history entry. */
let historySavedPattern: string | null = null;

function historyPush(pattern: string): void {
  if (!pattern) return;
  const existing = searchHistory.indexOf(pattern);
  if (existing === 0) return;
  if (existing > 0) searchHistory.splice(existing, 1);
  searchHistory.unshift(pattern);
  if (searchHistory.length > HISTORY_MAX) {
    searchHistory.length = HISTORY_MAX;
  }
}

// "Has the user settled on this query?" lives on a separate timer
// from the 150ms search debounce. Pushing to history on every
// debounce tick captures intermediate prefixes (typing "foo bar"
// in fits and starts → "f", "fo", "foo", … all end up in history).
// Wait 2 seconds of pattern-stability before pushing; any change
// cancels the pending push.
const HISTORY_SETTLE_MS = 2000;
let historySettleGeneration = 0;
function scheduleHistoryPush(pattern: string): void {
  if (!pattern) return;
  const gen = ++historySettleGeneration;
  editor.delay(HISTORY_SETTLE_MS).then(() => {
    if (gen !== historySettleGeneration) return;
    if (!panel || panel.searchPattern !== pattern) return;
    if (historyIndex >= 0) return; // walking history; not user input
    historyPush(pattern);
  });
}

// =============================================================================
// Colors
// =============================================================================

type RGB = [number, number, number];

const C = {
  border: [80, 80, 100] as RGB,
  label: [160, 160, 180] as RGB,
  value: [255, 255, 255] as RGB,
  inputBg: [40, 40, 55] as RGB,
  statusOk: [100, 200, 100] as RGB,
  statusDim: [120, 120, 140] as RGB,
  toggleOn: [100, 200, 100] as RGB,
  toggleOff: [100, 100, 120] as RGB,
  button: [80, 140, 220] as RGB,
  buttonFg: [255, 255, 255] as RGB,
  filePath: [220, 160, 80] as RGB,
  fileIcon: [100, 180, 220] as RGB,
  lineNum: [120, 120, 140] as RGB,
  matchBg: [0, 140, 160] as RGB,
  matchFg: [255, 255, 255] as RGB,
  selectedBg: [45, 50, 70] as RGB,
  checkOn: [100, 200, 100] as RGB,
  checkOff: [100, 100, 120] as RGB,
  dim: [90, 90, 110] as RGB,
  expandIcon: [140, 140, 160] as RGB,
  separator: [60, 60, 75] as RGB,
  help: [100, 100, 120] as RGB,
  cursor: [255, 255, 255] as RGB,
  cursorBg: [200, 200, 200] as RGB,
};

// =============================================================================
// Helpers
// =============================================================================

function byteLen(s: string): number {
  return editor.utf8ByteLength(s);
}

/** Count display columns (codepoints; approximation for monospace terminal). */
function charLen(s: string): number {
  let len = 0;
  for (const _c of s) { len++; }
  return len;
}

function padStr(s: string, width: number): string {
  const len = charLen(s);
  if (len >= width) return s;
  return s + " ".repeat(width - len);
}

/** Truncate to at most maxLen display columns (codepoint-aware). */
function truncate(s: string, maxLen: number): string {
  const sLen = charLen(s);
  if (sLen <= maxLen) return s;
  if (maxLen <= 3) {
    let result = "";
    let count = 0;
    for (const c of s) {
      if (count >= maxLen) break;
      result += c;
      count++;
    }
    return result;
  }
  let result = "";
  let count = 0;
  for (const c of s) {
    if (count >= maxLen - 3) break;
    result += c;
    count++;
  }
  return result + "...";
}

/** The UTF-16 index in `text` of its UTF-8 byte offset `byte` (clamped to
 *  the text). A binary search over native byte counts, so a long line —
 *  a minified bundle's 50 000 characters — costs a few calls rather than
 *  a walk through it codepoint by codepoint. */
function utf16IndexOfByte(text: string, byte: number): number {
  let lo = 0;
  let hi = text.length;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (editor.utf8ByteLength(text.slice(0, mid)) < byte) lo = mid + 1;
    else hi = mid;
  }
  return lo;
}

// Get the active field's text
function getActiveFieldText(): string {
  if (!panel) return "";
  return panel.queryField === "search" ? panel.searchPattern : panel.replaceText;
}

// Set the active field's text
function setActiveFieldText(text: string): void {
  if (!panel) return;
  if (panel.queryField === "search") {
    if (panel.searchPattern !== text) {
      // Pattern changed → any cached result no longer applies. See §17.
      panel.searchPerformed = false;
    }
    panel.searchPattern = text;
  } else {
    panel.replaceText = text;
  }
}

// =============================================================================
// Mode — uses allowTextInput for inline editing (supports all keyboard layouts)
// =============================================================================

// The focused control answers a key first — a field types, moves its caret
// and edits; the match tree walks, opens and folds; a toggle or button runs
// on Enter/Space; Tab walks the controls — so the mode binds only the
// panel's own commands, and ↑/↓ for the search field's history (a
// single-line field leaves them).
const modeBindings: string[][] = [
  ["Up", "search_replace_nav_up", "on:searchField"],
  ["Down", "search_replace_nav_down", "on:searchField"],
  ["M-c", "search_replace_toggle_case"],
  ["M-r", "search_replace_toggle_regex"],
  ["M-w", "search_replace_toggle_whole_word"],
  ["M-Return", "search_replace_replace_all"],
  ["S-Return", "search_replace_replace_scoped"],
  // Match navigation (issue #2434). Also bound in keymaps/default.json
  // for the editor (normal) context; binding them in the panel mode too
  // means the same key advances matches whether focus is in the panel
  // or back in the source buffer after an edit.
  ["C-M-Right", "search_replace_next_match"],
  ["C-M-Left", "search_replace_prev_match"],
  ["Escape", "search_replace_close"],
];

editor.defineMode("search-replace-list", modeBindings, true, true);

// Printable input flows through the widget runtime: mode_text_input
// → widgetCommand(textInputChar(text)) → host computes new value +
// cursor on the focused TextInput → widget_event "change" → plugin
// updates its model from the event payload (see the widget_event
// handler at the bottom of the file).
function mode_text_input(args: { text: string }): void {
  if (!panel || !args?.text) return;
  panel.widgetPanel?.command(textInputChar(args.text));
}
registerHandler("mode_text_input", mode_text_input);

// =============================================================================
// File grouping
// =============================================================================

function getRelativePath(filePath: string, root: string = panel?.root ?? editor.getCwd()): string {
  const cwd = root;
  if (filePath.startsWith(cwd)) {
    return filePath.slice(cwd.length + 1);
  }
  return filePath;
}

function getFileExtBadge(path: string): string {
  const dot = path.lastIndexOf(".");
  if (dot < 0) return "  ";
  const ext = path.slice(dot + 1).toUpperCase();
  if (ext.length <= 2) return ext.padEnd(2);
  return ext.slice(0, 2);
}

/** Natural ("human") ordering of two display paths (#2435). Splits each
 *  string into alternating non-digit / digit runs and compares digit
 *  runs by numeric value so `file2` sorts before `file10` rather than
 *  after it. Non-digit runs compare case-insensitively first (so `B`
 *  doesn't jump ahead of `a`) with a case-sensitive tiebreak to keep
 *  the order total and stable. Path separators are ordinary characters,
 *  which keeps each directory's files grouped together. */
function naturalCompare(a: string, b: string): number {
  const re = /\d+|\D+/g;
  const ap = a.match(re) ?? [];
  const bp = b.match(re) ?? [];
  const n = Math.min(ap.length, bp.length);
  for (let i = 0; i < n; i++) {
    const x = ap[i];
    const y = bp[i];
    const xNum = x.charCodeAt(0) >= 48 && x.charCodeAt(0) <= 57;
    const yNum = y.charCodeAt(0) >= 48 && y.charCodeAt(0) <= 57;
    if (xNum && yNum) {
      const dx = parseInt(x, 10);
      const dy = parseInt(y, 10);
      if (dx !== dy) return dx < dy ? -1 : 1;
      // Equal value but different width (leading zeros): shorter first.
      if (x.length !== y.length) return x.length - y.length;
    } else {
      const xl = x.toLowerCase();
      const yl = y.toLowerCase();
      if (xl !== yl) return xl < yl ? -1 : 1;
      if (x !== y) return x < y ? -1 : 1;
    }
  }
  return ap.length - bp.length;
}

function buildFileGroups(results: SearchResult[]): FileGroup[] {
  const map = new Map<string, SearchResult[]>();
  const order: string[] = [];
  for (const r of results) {
    const key = r.match.file;
    if (!map.has(key)) {
      map.set(key, []);
      order.push(key);
    }
    map.get(key)!.push(r);
  }
  const groups = order.map(absPath => ({
    relPath: getRelativePath(absPath),
    absPath,
    expanded: true,
    matches: map.get(absPath)!,
  }));
  groups.sort((a, b) => naturalCompare(a.relPath, b.relPath));
  return groups;
}

/** Re-order `panel.fileGroups` into natural path order in place,
 *  preserving each file's expansion state across the re-index. The
 *  streaming search path appends files in completion order (the project
 *  walk runs them through a parallel pool, so arrival order is
 *  effectively random); call this once a search finishes so the
 *  reviewer sees a stable, sorted list (#2435). Expansion keys are
 *  positional (`file:<index>`), so the set is rebuilt from the files
 *  that were expanded before the sort. */
function sortFileGroups(): void {
  if (!panel) return;
  const expandedPaths = new Set<string>();
  for (let i = 0; i < panel.fileGroups.length; i++) {
    if (panel.expandedFileKeys.has(`file:${i}`)) {
      expandedPaths.add(panel.fileGroups[i].absPath);
    }
  }
  panel.fileGroups.sort((a, b) => naturalCompare(a.relPath, b.relPath));
  panel.expandedFileKeys.clear();
  panel.knownFileKeys.clear();
  for (let i = 0; i < panel.fileGroups.length; i++) {
    const key = `file:${i}`;
    panel.knownFileKeys.add(key);
    if (expandedPaths.has(panel.fileGroups[i].absPath)) {
      panel.expandedFileKeys.add(key);
    }
  }
}

interface FlatItem {
  type: "file" | "match";
  fileIndex: number;
  matchIndex?: number;
}

// Emit every file row + every match row in declaration order. The
// Tree widget filters out descendants of collapsed nodes at render
// time — the plugin always sends the full hierarchy. Plugin code
// that needs to map a `selected_index` back to the underlying match
// (e.g. `doReplaceScoped`) walks this same flat list.
function buildFlatItems(): FlatItem[] {
  if (!panel) return [];
  const items: FlatItem[] = [];
  for (let fi = 0; fi < panel.fileGroups.length; fi++) {
    items.push({ type: "file", fileIndex: fi });
    const group = panel.fileGroups[fi];
    for (let mi = 0; mi < group.matches.length; mi++) {
      items.push({ type: "match", fileIndex: fi, matchIndex: mi });
    }
  }
  return items;
}

// =============================================================================
// Get actual viewport width
// =============================================================================

function getViewportWidth(): number {
  const vp = editor.getViewport();
  if (vp && vp.width > 0) return vp.width;
  return DEFAULT_WIDTH;
}

// =============================================================================
// Panel content builder — compact two-line control bar + match tree
// =============================================================================

// The Replace All button. Its label tracks scope (§1):
//   * allFiles=true  → "Replace All (Alt+Ret)"
//   * allFiles=false → "Replace All in <file> (Alt+Ret)"
// sourceBufferRelPath is empty for an unsaved buffer, in which case we
// fall back to the all-files label since restricting to a path-less
// buffer can't match anything anyway.
function replaceAllButtonSpec(): WidgetSpec {
  const scoped = !!panel && !panel.allFiles && !!panel.sourceBufferRelPath;
  const replLabel = scoped
    ? editor.t("panel.replace_all_in_file_btn", { file: panel!.sourceBufferRelPath })
    : editor.t("panel.replace_all_btn");
  return button(replLabel, { intent: "primary", key: "replaceAll" });
}

// True when the Replace All button sits on the scope row rather than the
// options row: a one-file scope names the file in the button, which then
// no longer fits beside the toggles (it was cut off against them).
function replaceAllOnScopeRow(): boolean {
  return !!panel && !panel.allFiles && !!panel.sourceBufferRelPath;
}

// Build the typed Row spec for the options line (the toggles, plus the
// Replace All button unless it sits on the scope row). Dispatched through
// the host's Toggle/Button widgets so styling, theme keys, and focus
// affordance match every other plugin.
function buildOptionsRowSpec(): WidgetSpec {
  if (!panel) return col();
  const { caseSensitive, useRegex, wholeWords, allFiles } = panel;

  const caseLabel = editor.t("panel.case_toggle");
  const regexLabel = editor.t("panel.regex_toggle");
  const wholeLabel = editor.t("panel.whole_toggle");
  const allFilesLabel = editor.t("panel.all_files_toggle");

  const children: WidgetSpec[] = [
    spacer(1),
    toggle(allFiles, allFilesLabel, { key: "allFiles" }),
    spacer(2),
    toggle(caseSensitive, caseLabel, { key: "case" }),
    spacer(2),
    toggle(useRegex, regexLabel, { key: "regex" }),
    spacer(2),
    toggle(wholeWords, wholeLabel, { key: "whole" }),
  ];
  if (!replaceAllOnScopeRow()) {
    children.push(flexSpacer(), replaceAllButtonSpec());
  }
  return row(...children);
}

// Build the scope-info row shown only when allFiles=false. Tells the
// user which single file the search is restricted to, and carries the
// "Replace All in <file>" button after it. When
// allFiles=true the function returns an empty col() (the spec composer
// skips it).
function buildScopeRowSpec(): WidgetSpec {
  if (!panel) return col();
  if (panel.allFiles) return col();
  const scopeLabel = panel.sourceBufferRelPath
    ? editor.t("panel.scope_row_file", { file: panel.sourceBufferRelPath })
    : editor.t("panel.scope_row_unnamed");
  const scopeText = raw([{
    text: " " + scopeLabel,
    properties: { type: "scope-row" },
    style: { fg: C.label, italic: true },
  }]);
  if (!replaceAllOnScopeRow()) return scopeText;
  // Wrapping, so a panel too narrow for both puts the button on a line of
  // its own instead of cutting its label off. The button carries its own
  // one-cell indent, so a wrapped line keeps the rows' left margin.
  return wrappingRow(scopeText, spacer(1), row(spacer(1), replaceAllButtonSpec()));
}

// Build the typed Row spec for line 1 (search + replace fields with
// trailing match-count stats). Was previously hand-rolled with two
// `buildFieldDisplay` calls + manual cursor overlays; now uses the
// host's TextInput widget for both fields (theme-keyed focus + input
// background, cursor highlight at the right byte position). The
// match-stats portion stays in Raw because it has bespoke
// truncated-warning styling (`[255, 180, 50]`) and isn't a control.
// Build just the matchStats text + inline overlays. Pulled out of
// `buildLine1Spec` so the streaming pump can refresh it via the
// `setRawEntries` mutation on the keyed `matchStats` raw widget —
// without re-emitting the full panel spec (which forces js_to_json
// over the entire 5 000-node tree and blocks the JS thread).
function buildMatchStatsEntries(): TextPropertyEntry[] {
  if (!panel) return [];
  const totalMatches = panel.searchResults.length;
  const fileCount = panel.fileGroups.length;
  const truncated = panel.truncated;
  const truncatedSuffix = truncated ? " " + editor.t("panel.limited") : "";
  let matchStats = "";
  if (totalMatches > 0) {
    matchStats = "  " + editor.t("panel.match_stats", { count: String(totalMatches), files: String(fileCount) }) + truncatedSuffix;
  } else if (panel.busy && panel.searchPattern) {
    matchStats = "  " + editor.t("panel.searching");
  } else if (panel.searchPattern && panel.searchPerformed && !panel.busy) {
    matchStats = "  " + editor.t("panel.no_matches");
  }
  if (matchStats.length === 0) return [];
  const overlays: InlineOverlay[] = [];
  if (truncated && totalMatches > 0) {
    const statsWithoutSuffix = "  " + editor.t("panel.match_stats", {
      count: String(totalMatches),
      files: String(fileCount),
    });
    const countEnd = byteLen(statsWithoutSuffix);
    overlays.push({ start: 0, end: countEnd, style: { fg: C.statusOk } });
    overlays.push({
      start: countEnd,
      end: countEnd + byteLen(truncatedSuffix),
      style: { fg: [255, 180, 50] as RGB, bold: true },
    });
  } else {
    overlays.push({
      start: 0,
      end: byteLen(matchStats),
      style: { fg: totalMatches > 0 ? C.statusOk : C.statusDim },
    });
  }
  return [{ text: matchStats, inlineOverlays: overlays }];
}

function buildLine1Spec(): WidgetSpec {
  if (!panel) return col();
  const { searchPattern, replaceText, focusPanel, queryField, cursorPos } = panel;
  const qFocusSearch = focusPanel === "query" && queryField === "search";
  const qFocusReplace = focusPanel === "query" && queryField === "replace";
  const searchVal = searchPattern || "";
  const replaceVal = replaceText || "";
  // The plugin tracks `cursorPos` as a character offset; the widget
  // wants a UTF-8 byte offset. For ASCII they're equal; for the
  // multi-byte case we convert via byteLen of the prefix.
  const searchCursorByte = qFocusSearch ? byteLen(searchVal.substring(0, cursorPos)) : -1;
  const replaceCursorByte = qFocusReplace ? byteLen(replaceVal.substring(0, cursorPos)) : -1;
  const searchLabel = editor.t("panel.search_label");
  const replLabel = editor.t("panel.replace_label");

  return row(
    spacer(1),
    textInput(searchVal, {
      label: searchLabel,
      focused: qFocusSearch,
      cursorByte: searchCursorByte,
      fieldWidth: 25,
      key: "searchField",
    }),
    spacer(2),
    textInput(replaceVal, {
      label: replLabel,
      focused: qFocusReplace,
      cursorByte: replaceCursorByte,
      fieldWidth: 25,
      key: "replaceField",
    }),
    raw(buildMatchStatsEntries(), "matchStats"),
  );
}

// Workspace-file filter, matching the dedicated files-to-include field in
// VS Code's search panel. It stays on its own row so useful path globs aren't
// squeezed by the search/replace fields and match stats.
function buildFileGlobRowSpec(): WidgetSpec {
  if (!panel) return col();
  return row(
    spacer(1),
    textInput(panel.fileGlob, {
      label: editor.t("panel.files_label"),
      focused: false,
      cursorByte: -1,
      fieldWidth: 54,
      key: "fileGlobField",
    }),
  );
}

// Stable key for a flat tree item — used as the List item key so
// click events bounce back to the same logical match across
// re-renders. File rows use `file:<n>`; match rows use
// `match:<file>/<m>`.
function flatItemKey(item: FlatItem): string {
  if (item.type === "file") return `file:${item.fileIndex}`;
  return `match:${item.fileIndex}/${item.matchIndex}`;
}

// Render one flat tree item as a single TextPropertyEntry. The
// Tree widget owns the indent (depth * 2 spaces) + disclosure glyph
// (▶ / ▼) prefix and the selection bg — this function emits *just*
// the row's content starting from offset 0 of the row's body. Files
// pass `depth: 0, hasChildren: true`; matches pass `depth: 1,
// hasChildren: false` (see `buildMatchListSpec`).
//
// Row content is described as a sequence of styled segments rather
// than a pre-rendered string + offset overlays. The host concats
// segments and computes the byte offsets natively in Rust, so the
// plugin doesn't count codepoints or bytes for layout-piece widths
// at all. Per-row freeform overlays (e.g. pattern-match highlights
// inside the context substring) ride on the relevant segment via
// its `overlays` field, addressed in char units relative to that
// segment alone.
/** One rendered row: the entry, plus the char span the row exists to show.
 *
 *  The span is the host's to act on — it rests the row's window on it when
 *  the row is wider than the panel, and the reader pans away from there. The
 *  plugin no longer cuts the string itself: it sends the capped context whole
 *  and says where the interesting part is, which is what makes panning left
 *  able to reach the head of the line at all. See `TreeNode.windowAnchor`. */
type RenderedRow = { entry: TextPropertyEntry; anchor?: TextWindowAnchor };

function renderFlatItemEntry(item: FlatItem, W: number): RenderedRow {
  if (!panel) return { entry: { text: "" } };
  if (item.type === "file") {
    const group = panel.fileGroups[item.fileIndex];
    const badge = getFileExtBadge(group.relPath);
    const matchCount = group.matches.length;
    const selectedInFile = group.matches.filter(m => m.selected).length;
    return {
      entry: styledRow(
        [
          { text: badge, style: { fg: C.fileIcon, bold: true } },
          { text: " " },
          { text: group.relPath, style: { fg: C.filePath } },
          { text: ` (${selectedInFile}/${matchCount})` },
        ],
        {
          // Host prefix at depth 0: disclosure (▶/▼) + space + checkbox
          // ([v]/[ ]) + space = 6 cols.
          padToChars: Math.max(0, W - 6),
          properties: { type: "file-row", fileIndex: item.fileIndex },
        },
      ),
    };
  }
  // Match row. The Tree widget's prefix at depth=1 is 6 cols
  // (4 indent + 2 alignment). Use the remaining width for content.
  const group = panel.fileGroups[item.fileIndex];
  const result = group.matches[item.matchIndex!];
  const location = `${group.relPath}:${result.match.line}`;
  // Hard-cap the context length BEFORE any per-codepoint work below.
  // Minified CSS / JSON / single-line generated files routinely have
  // match context strings 5 000-50 000 chars long. The downstream
  // `truncate()` does `for (const c of s)` (per-codepoint iteration
  // + O(N²) string concatenation in QuickJS); at 5 000 chars and 50
  // items per flush that adds up to several hundred ms of JS work
  // per pump iteration, blocking Tab and other queued requests.
  // A panel viewport is at most a few hundred chars wide, so anything
  // past ~512 chars is invisible anyway.
  const CONTEXT_HARD_CAP = 512;
  const rawCtx = result.match.context;
  // Anchor that cap on the *match*, not on the start of the line.
  // Slicing from 0 threw away the only part of the row anyone opened
  // it for whenever the match sat past the cap — and the same for the
  // display-width truncation below (issue #1580: a match at column 257
  // of a 290-char line rendered as `start xxxx…`, with the matched
  // text nowhere on screen).
  //
  // Where the match is, from the search that found it (`contextOffset`),
  // in UTF-16 units of `rawCtx`; its end clamped to the line — a multi-line
  // match runs past it.
  const { contextOffset, length } = result.match;
  const anchor = utf16IndexOfByte(rawCtx, contextOffset);
  const anchorEnd = Math.max(anchor, utf16IndexOfByte(rawCtx, contextOffset + length));
  const capStart = rawCtx.length > CONTEXT_HARD_CAP
    ? Math.max(0, Math.min(anchor - CONTEXT_HARD_CAP / 2, rawCtx.length - CONTEXT_HARD_CAP))
    : 0;
  const capped = rawCtx.slice(capStart, capStart + CONTEXT_HARD_CAP);
  // Leading indentation is noise worth trimming when the window starts
  // at the beginning of the line; a window that already starts mid-line
  // must not shift further, or the offsets below drift.
  const context = capStart === 0 ? capped.trim() : capped.replace(/\s+$/, "");
  // Host prefix consumes:
  //   indent (depth=1) = 2
  //   leaf-alignment   = 2 (in lieu of disclosure glyph)
  //   checkbox + space = 4 ([v] + " ")
  // Total: 8 cols.
  const innerWidth = Math.max(0, W - 8);

  // Where this row's match sits in `context`, after the cap slice and
  // the leading trim above, in codepoints.
  const trimmedLead = capStart === 0 ? capped.length - capped.trimStart().length : 0;
  const clampToContext = (i: number) => Math.max(0, Math.min(i - capStart - trimmedLead, context.length));
  const matchStart = clampToContext(anchor);
  const matchEnd = clampToContext(anchorEnd);
  const span = {
    start: charLen(context.slice(0, matchStart)),
    length: charLen(context.slice(matchStart, matchEnd)),
  };
  // **The whole capped context goes to the host, not a slice of it.**
  //
  // Fitting a row to the panel used to happen here, which meant the row the
  // host received was already the only thing that could ever be read: there
  // was nothing to the left of the window's `…` and nothing to the right, so
  // there was nothing to pan (issue #1580). The host fits the row now, and
  // this says where the window should rest — so panning left walks back
  // through the head of the line and panning right runs to its tail.
  //
  // The cap is unchanged: `CONTEXT_HARD_CAP` still bounds every per-codepoint
  // walk below, and it is what bounds how far a pan can travel.
  //
  // The row's own match is highlighted: what the search matched, whole
  // words and regex alike, rather than a JS re-match of the pattern. Other
  // matches on the line have rows of their own.
  const ctxOverlays: InlineOverlay[] = span.length > 0
    ? [{ start: span.start, end: span.start + span.length, style: { bg: C.matchBg, fg: C.matchFg }, unit: "char" }]
    : [];

  const segments: StyledSegment[] = [
    { text: location, style: { fg: C.lineNum } },
    { text: " - " },
    { text: context, overlays: ctxOverlays },
  ];

  const entry = styledRow(segments, {
    padToChars: innerWidth,
    properties: { type: "match-row", fileIndex: item.fileIndex, matchIndex: item.matchIndex },
  });
  // The window is addressed to the whole row, so both numbers carry the
  // leading pieces' width. `location` is a path plus a line number — the
  // codepoint/UTF-16 distinction only bites on a non-BMP filename, where
  // being a codepoint or two out moves the resting window by that much and
  // nothing else.
  //
  // `pinned` keeps `path:line - ` in place while the context slides under it:
  // it is which match this row *is*, and rows that pan it away cannot be told
  // apart.
  const pinned = charLen(location) + 3;
  return {
    entry,
    anchor: {
      pinned,
      start: pinned + span.start,
      len: span.length,
    },
  };
}

// Convert a slice of `FlatItem`s into the corresponding TreeNodes.
// Pulled out of `buildMatchListSpec` so the streaming path can use it
// to build deltas for `appendTreeNodes` — it must produce nodes
// identical to the full-spec rebuild for the same items, so
// auto-expand of first-seen file rows happens here.
function flatItemsToTreeNodes(
  flatItems: FlatItem[],
  itemKeys: string[],
  W: number,
): TreeNode[] {
  return flatItems.map((item, i) => {
    const { entry, anchor } = renderFlatItemEntry(item, W);
    if (item.type === "file") {
      const k = itemKeys[i];
      if (!panel!.knownFileKeys.has(k)) {
        panel!.knownFileKeys.add(k);
        panel!.expandedFileKeys.add(k);
      }
      // File-row checkbox derives from children: checked iff every
      // match in this file is selected.
      const fileChecked = panel!.fileGroups[item.fileIndex].matches.every(m => m.selected);
      return treeNode(entry, { depth: 0, hasChildren: true, checked: fileChecked });
    }
    const matchSelected = panel!.fileGroups[item.fileIndex]
      .matches[item.matchIndex!].selected;
    return treeNode(entry, {
      depth: 1,
      hasChildren: false,
      checked: matchSelected,
      windowAnchor: anchor,
    });
  });
}

// Build the typed spec for the matches body — either a Tree widget
// (when there are matches) or a Raw cell with the empty/prompt
// message. The Tree widget owns scroll, selection styling, click
// routing, and host-managed expand/collapse — the plugin sends
// the *full* hierarchy on every render and the host filters
// children of collapsed file rows.
function buildMatchListSpec(): WidgetSpec {
  if (!panel) return col();
  const W = Math.max(MIN_WIDTH, panel.viewportWidth - 2);
  const totalMatches = panel.searchResults.length;

  // Empty-state branches: pristine / searching / no-results /
  // pattern-set-but-no-search-yet. See §17 of
  // docs/internal/search-replace-scope-replan-on-widgets.md.
  //
  // When the pattern is mutated while a previous search's results are
  // still in panel.searchResults, render the stale results (fall
  // through to the Tree branch below) until the next search
  // completes — dropping back to "Type a search pattern above"
  // mid-edit feels jumpy.
  const emptyState = (key: string) =>
    raw([{
      text: padStr("  " + editor.t(key), W),
      properties: { type: "empty" },
      style: { fg: C.dim },
    }]);
  if (!panel.searchPattern) {
    return emptyState("panel.type_pattern");
  }
  if (panel.busy && totalMatches === 0) {
    return emptyState("panel.searching");
  }
  if (totalMatches === 0 && panel.searchPerformed && !panel.busy) {
    return emptyState("panel.no_matches");
  }
  if (totalMatches === 0) {
    // Pattern in flight but no search has run yet (and no cached
    // results). Same friendly hint as pristine.
    return emptyState("panel.type_pattern");
  }

  const flatItems = buildFlatItems();
  const itemKeys = flatItems.map(flatItemKey);
  const nodes = flatItemsToTreeNodes(flatItems, itemKeys, W);
  const selectedIndex = panel.focusPanel === "matches" ? panel.matchIndex : -1;

  // No `visibleRows`: the host auto-sizes the tree to the panel height
  // minus whatever rows the surrounding chrome occupies. (This used to
  // be `getViewportHeight() - fixedRows` with a hand-counted chrome
  // constant that had already drifted from its own comment.)
  return tree({
    nodes,
    itemKeys,
    selectedIndex,
    expandedKeys: [...panel.expandedFileKeys],
    checkable: true,
    key: "matchTree",
  });
}

// Phase selector for `buildPanelEntries`. The hand-rolled options
// row and line-1 query fields were extracted into typed widget specs
// (`buildOptionsRowSpec`, `buildLine1Spec`); this parameter lets
// callers ask for the body before the options row ("preOptions"),
// the body after it ("postOptions"), or — for tests / fallback
// paths — both with no gap ("all"). Today "preOptions" is empty
// because line 1 lives in `buildLine1Spec`; the parameter remains
// for symmetry and to keep the boundary explicit.
type BuildPhase = "all" | "preOptions" | "postOptions";

function buildPanelEntries(phase: BuildPhase = "all"): TextPropertyEntry[] {
  if (!panel) return [];
  const { searchPattern, replaceText, searchResults, fileGroups, focusPanel, queryField,
    optionIndex, caseSensitive, useRegex, wholeWords, cursorPos } = panel;
  // The line-1 + options-row variables are still destructured for
  // readability with the rest of the function but are now consumed
  // by `buildLine1Spec()` and `buildOptionsRowSpec()` (composed into
  // the spec at update time).
  void searchPattern;
  void replaceText;
  void searchResults;
  void fileGroups;
  void focusPanel;
  void queryField;
  void cursorPos;
  void optionIndex;
  void caseSensitive;
  void useRegex;
  void wholeWords;

  const W = Math.max(MIN_WIDTH, panel.viewportWidth - 2);
  const entries: TextPropertyEntry[] = [];

  const totalMatches = searchResults.length;
  const fileCount = fileGroups.length;

  // ── Line 1 (search/replace fields + match-count stats) is now
  //    rendered by `buildLine1Spec()` — see updatePanelContent. The
  //    pre-options phase therefore returns no entries; the spec
  //    composes the typed Row directly between the col children. ──

  // ── Line 2 (options toggles + Replace All button) is now rendered
  //    by the host as a `Row { Toggle, Toggle, Toggle, Spacer, Button }`
  //    spec — see `buildOptionsRowSpec` and `updatePanelContent`.
  //    `buildPanelEntries` is split into a "pre-options" half (this
  //    function up to here) and a "post-options" tail (everything from
  //    the separator onward). `updatePanelContent` weaves the spec
  //    between them so the visual order stays identical to before. ──
  if (phase === "preOptions") return entries;
  // ── For phase==="postOptions", also drop the line-1 entry pushed
  //    above so the caller can compose: `col(raw(pre), optionsRow,
  //    raw(post), hintBar)` without duplicating line 1.
  if (phase === "postOptions") entries.length = 0;

  // ── Separator ──
  const sepChar = "─";
  const matchesLabel = totalMatches > 0
    ? " " + editor.t("panel.matches_count", { count: String(totalMatches), files: String(fileCount) }) + (panel.truncated ? " " + editor.t("panel.limited") : "") + " "
    : " " + editor.t("panel.matches_title") + " ";
  const sepRemaining = W - charLen(matchesLabel);
  const sepLeft = Math.floor(sepRemaining / 2);
  const sepRight = sepRemaining - sepLeft;
  const sepLine = (sepLeft > 0 ? sepChar.repeat(sepLeft) : "") + matchesLabel + (sepRight > 0 ? sepChar.repeat(sepRight) : "");
  entries.push({
    text: sepLine + "\n",
    properties: { type: "separator" },
    style: { fg: C.separator },
    inlineOverlays: [{
      start: byteLen(sepChar.repeat(sepLeft)),
      end: byteLen(sepChar.repeat(sepLeft) + matchesLabel),
      style: { fg: C.label, bold: true },
    }],
  });

  // ── Matches tree is now rendered by `buildMatchListSpec()` —
  //    see `updatePanelContent`. The List widget owns scroll
  //    offset (auto-clamps to keep selection in view) and click
  //    routing. ──

  // The help footer is no longer pushed here — it's now rendered by
  // the host's HintBar widget (see updatePanelContent).
  return entries;
}

// Build the hint entries for the panel footer.
//
// Source of truth is the existing `panel.help` i18n string (format:
// `Tab:section  ↑↓:nav  …`); `parseHintString` splits it into typed
// `HintEntry[]` so the host's HintBar widget can style the keys
// portion via the `ui.help_key_fg` theme key — matching every other
// plugin's footer.
function buildHelpHints(): HintEntry[] {
  // Source of truth is the existing `panel.help` i18n string. The
  // pre-widget version appended a `↑↓` scroll indicator computed
  // from `panel.scrollOffset`; the List widget now owns scroll
  // state, so the plugin no longer knows the scroll position.
  // Scroll feedback is implicit (the visible window of items shifts
  // visibly when navigating); explicit indicators can come back as
  // a List-emitted prop once needed.
  return parseHintString(editor.t("panel.help"));
}

// Build field display string: [value] with cursor
function buildFieldDisplay(value: string, cursorPos: number, maxLen: number): string {
  const display = value.length > maxLen ? value.slice(0, maxLen - 1) + "…" : value;
  if (cursorPos >= 0) {
    // Show cursor as underscore or pipe at position
    return "[" + display + "]";
  }
  return "[" + display + "]";
}

// Add cursor overlay at the right byte position within a field
function addCursorOverlay(value: string, cursorPos: number, fieldByteStart: number, overlays: InlineOverlay[]): void {
  if (cursorPos < 0) return;
  const beforeCursor = value.substring(0, cursorPos);
  const cursorBytePos = fieldByteStart + byteLen(beforeCursor);
  // Highlight the character at cursor position (or the closing bracket if at end)
  const charAtCursor = cursorPos < value.length ? value.charAt(cursorPos) : "]";
  const cursorByteEnd = cursorBytePos + byteLen(charAtCursor);
  overlays.push({ start: cursorBytePos, end: cursorByteEnd, style: { fg: [0, 0, 0], bg: C.cursorBg } });
}

// Append pattern-match highlight overlays (one per occurrence) to
// `overlays`. Offsets are in char (codepoint) units within `text`
// itself — the caller is expected to attach `overlays` to a
// segment whose body equals `text`, so the host shifts them into
// entry-coordinate space during segment resolution.
//
// `text` and `pattern` are treated as JS UTF-16 strings. For BMP
// content (which includes nearly all source code) UTF-16 code unit
// indices and Unicode codepoint indices coincide, so `indexOf` /
// `RegExp.exec` indices map directly to char offsets without a
// per-overlay codepoint walk.
// =============================================================================
// Panel update
// =============================================================================

function updatePanelContent(): void {
  if (!panel) return;
  // Refresh viewport width each time
  panel.viewportWidth = getViewportWidth();

  // Migration step 4 (see docs/internal/plugin-widget-library-design.md
  // §10): the entire visible panel is now typed widgets except for
  // a single `Raw` separator entry.
  //
  //   * `Row{ Spacer, TextInput, Spacer, TextInput, Raw{ stats } }`
  //                                       — search/replace inputs +
  //                                       trailing match-count stats.
  //   * `Row{ Toggle, Toggle, Toggle, Spacer, Button }`
  //                                       — case/regex/whole + Replace All.
  //   * `HintBar{ ... }`                  — keyboard-hint row, sits
  //                                       directly above the matches
  //                                       section.
  //   * `Raw{ separator entry }`         — matches divider.
  //   * `List{ ... }` or `Raw{empty msg}` — virtual-scrolled match
  //                                       rows (host owns scroll +
  //                                       selection styling +
  //                                       click routing). Last child
  //                                       so the match list is the
  //                                       final thing in the buffer.
  if (!panel.widgetPanel) {
    panel.widgetPanel = new WidgetPanel(panel.resultsBufferId);
  }
  panel.widgetPanel.set(
    col(
      buildLine1Spec(),
      buildFileGlobRowSpec(),
      buildOptionsRowSpec(),
      buildScopeRowSpec(),
      hintBar(buildHelpHints()),
      raw(buildPanelEntries("postOptions"), "separator"),
      buildMatchListSpec(),
    ),
  );
  // The Tree's `expandedKeys` field on the spec is initial-only —
  // `mountWidgetPanel` seeds the host's instance state, and
  // `updateWidgetPanel` ignores it (instance state is authoritative
  // after first render). So we push expansion changes through the
  // explicit mutator on every update; this covers the case where
  // a new file group enters the result set in a later search and
  // needs to be force-expanded by default. The mutator is a no-op
  // when the tree isn't mounted yet (first `set()` call).
  if (panel.searchPattern && panel.searchResults.length > 0) {
    panel.widgetPanel.setExpandedKeys(
      "matchTree",
      [...panel.expandedFileKeys],
    );
  }
}

// =============================================================================
// Search
// =============================================================================

/** Pump cadence between successive `take()` drains (ms). The host writes
 * matches at full speed; this knob bounds the UI rebuild rate. */
const SEARCH_PUMP_INTERVAL_MS = 50;
/** Don't flush more often than this. */
const UI_FLUSH_INTERVAL_MS = 80;
/** Hard cap on each `appendTreeNodes` flush payload. Each TreeNode in
 *  the payload costs ~60 µs in `js_to_json` + `serde_json::from_value`
 *  on the JS thread (measured: AppendTreeNodes(1296) = 88 ms).
 *  Larger payloads → longer per-iteration JS block → user input
 *  (Tab, typed char, Esc) waits in the plugin thread's request
 *  channel. Keeping the cap at ~100 keeps each flush ≤ 10 ms so
 *  queued Tab requests can interleave between pump iterations. */
const UI_FLUSH_MAX_DELTA = 100;

/**
 * Perform a streaming search using a pull-based handle. The host writes
 * matches at full speed into shared state; this loop drains them via
 * `handle.take()` and rebuilds the UI between drains. There are no
 * per-chunk callbacks crossing the FFI boundary, so the host's main
 * thread is free to process input and render between pumps.
 */
async function performSearch(
  p: PanelState | null,
  pattern: string,
  silent?: boolean,
): Promise<SearchResult[]> {
  if (!p) return [];

  const generation = ++p.searchGeneration;
  // Each fresh search resets the per-file expansion set: previous
  // results may have included files that don't appear in the new
  // result set, and the user's collapse state for the *previous*
  // result set isn't meaningful for the new one.
  p.expandedFileKeys.clear();
  p.knownFileKeys.clear();
  // New search → reset the streaming-append checkpoint. The first
  // batch of results will trigger a full `updatePanelContent()`
  // (mounting the empty Tree); subsequent batches append deltas to
  // that mounted Tree.
  //
  // Number of `buildFlatItems()` entries already pushed to the host via
  // `appendTreeNodes`. Zero means "nothing streamed into the mounted tree
  // yet": the next batch does a full `updatePanelContent()` instead, so the
  // Tree exists for later appends. Also reset while the panel's window is in
  // the background, where nothing is drawn.
  let lastStreamingFlatCount = 0;
  // Absolute path → index into `p.fileGroups`, so each new match finds its
  // file group in O(1) instead of a full `buildFileGroups` per batch.
  const streamingFileIndexByPath = new Map<string, number>();
  // Matches taken from the host but not processed yet: a big batch is
  // drained CHUNK at a time, and `take()` is only called again once empty.
  let pendingMatches: GrepMatch[] = [];
  // Tree-append delta not flushed to the host yet; several chunks are
  // coalesced into one `appendTreeNodes` IPC (~20 ms each on the host).
  let pendingTreeDeltaItems: FlatItem[] = [];
  // New file-row keys whose expansion must go out with the next flush.
  let pendingNewExpandedKeys: string[] = [];
  // Wall-clock ms of the last UI flush.
  let lastUiFlush = 0;
  // Reset accumulating state so a re-search (debounce from typing,
  // toggle flip, scope change) starts from empty rather than
  // appending to the previous run's results. Drop the previous run's
  // anchor markers first so they don't leak on the source buffers.
  withPanel(p, clearMatchMarkers);
  p.searchResults = [];
  p.fileGroups = [];

  // Cancel any in-flight search before kicking off a new one. Without
  // this the prior search would keep walking the project until it
  // hit max_results, wasting CPU.
  if (p.searchHandle) {
    try { p.searchHandle.cancel(); } catch (_e) { /* ignore */ }
    p.searchHandle = null;
  }
  // Buffers of the panel's own window, by path, for anchoring matches. Read
  // per window, not from the active one: the search keeps running when the
  // user switches windows, and another window may hold its own buffer of
  // the same file (#3704). Refreshed every pump tick.
  let buffersByPath = windowBuffersByPath(p.windowId);

  try {
    const fixedString = !p.useRegex;
    const allResults: SearchResult[] = [];

    // Whole-word filtering is done Rust-side so maxResults is respected
    // correctly. "Current file only" searches just that buffer, as it is;
    // all files walks the project.
    const handle = editor.beginSearch(pattern, {
      fixedString,
      caseSensitive: p.caseSensitive,
      maxResults: MAX_RESULTS,
      wholeWords: p.wholeWords,
      ...(p.allFiles
        ? {
          fileGlob: p.fileGlob,
          // Lets the host search an unnamed/unsaved source buffer in-memory;
          // it has no on-disk file the project walk could otherwise reach.
          sourceBufferId: p.sourceBufferId,
        }
        // "Current file only": just that buffer, as it is.
        : { bufferId: p.sourceBufferId || editor.getActiveBufferId() }),
    });
    p.searchHandle = handle;

    let truncated = false;
    let producerError: string | null = null;

    while (true) {
      // Discard the in-flight search if a newer one started while we slept.
      // …or the panel was closed.
      if (generation !== p.searchGeneration || panels.get(p.windowId) !== p) {
        try { handle.cancel(); } catch (_e) { /* ignore */ }
        return allResults;
      }
      // Only the active window's panel is drawn. One in the background keeps
      // collecting results and is redrawn in full when its window is back.
      const shown = p === panel;
      if (!shown) {
        lastStreamingFlatCount = 0;
        p.needsRedraw = true;
      }

      // Drain matches in chunks of at most CHUNK per pump iteration.
      // `pendingMatches` accumulates anything the host gave us that we
      // haven't processed yet. This caps the per-iteration synchronous
      // JS work at O(CHUNK) so the event loop yields back to the host
      // promptly — without this, a single batch of 3000+ matches takes
      // ~700ms of JS time and queues every user keypress (Tab, typed
      // chars, Esc) for the duration of the search.
      //
      // Only call `handle.take()` when our queue is empty, so the host
      // doesn't keep us flooded; the producer pauses when the take()
      // returns nothing left to drain.
      let batchDone = false;
      let batchTruncated = false;
      let batchError: string | null = null;
      if (pendingMatches.length === 0) {
        const batch = handle.take();
        batchDone = batch.done;
        batchTruncated = batch.truncated;
        batchError = batch.error ?? null;
        for (const m of batch.matches) pendingMatches.push(m);
      }
      // Hard cap on per-iteration work. Each match in the chunk turns
      // into a TreeNode in the `appendTreeNodes` flush, and each
      // TreeNode costs ~60 µs in `js_to_json` + `from_value` on the
      // JS thread. Keeping the chunk small means each pump iteration
      // stays ≤ ~10 ms — short enough that queued Tab/typed-char
      // requests interleave smoothly between iterations.
      const CHUNK = 80;
      const chunkSize = Math.min(CHUNK, pendingMatches.length);
      const chunk = pendingMatches.splice(0, chunkSize);
      const moreInQueue = pendingMatches.length > 0;
      const deltaItems: FlatItem[] = [];
      const newExpandedKeys: string[] = []; // file rows added this batch
      for (const m of chunk) {
        const result: SearchResult = { match: m, selected: true };
        // Anchor the match to its buffer if the file is already open, so
        // edits made while stepping keep it in sync (#2583). Files opened
        // later are handled by the after_file_open hook.
        ensureMatchMarker(result, buffersByPath);
        allResults.push(result);
        let fileIdx = streamingFileIndexByPath?.get(m.file);
        if (fileIdx === undefined) {
          fileIdx = p.fileGroups.length;
          streamingFileIndexByPath?.set(m.file, fileIdx);
          p.fileGroups.push({
            relPath: getRelativePath(m.file, p.root),
            absPath: m.file,
            expanded: true,
            matches: [],
          });
          deltaItems.push({ type: "file", fileIndex: fileIdx });
          const fileKey = `file:${fileIdx}`;
          p.expandedFileKeys.add(fileKey);
          p.knownFileKeys.add(fileKey);
          newExpandedKeys.push(fileKey);
        }
        const matchIdx = p.fileGroups[fileIdx].matches.length;
        p.fileGroups[fileIdx].matches.push(result);
        deltaItems.push({ type: "match", fileIndex: fileIdx, matchIndex: matchIdx });
      }
      p.searchResults = allResults;
      // Coalesce the per-chunk delta into a pending buffer. Each
      // `appendTreeNodes` IPC costs ~20 ms on the host (spec mutation
      // + Tree-visible-rows recompute + virtual-buffer repaint).
      // Flushing every 250-match chunk means 20+ IPCs over a 5 000-
      // match search — that pile of host main-thread work is exactly
      // when queued Tab / typed-key events sit waiting. Flush only
      // every UI_FLUSH_INTERVAL_MS so the user sees the result list
      // grow at a steady ~5 Hz while leaving the host free to dispatch
      // input events between flushes.
      for (const it of deltaItems) pendingTreeDeltaItems.push(it);
      for (const k of newExpandedKeys) pendingNewExpandedKeys.push(k);
      const nowMs = Date.now();
      const producerFinished = batchDone && pendingMatches.length === 0;
      const dueToFlush =
        producerFinished ||
        pendingTreeDeltaItems.length >= UI_FLUSH_MAX_DELTA ||
        nowMs - lastUiFlush >= UI_FLUSH_INTERVAL_MS;
      if (!shown) {
        // Nothing to draw into; the redraw on return covers it.
        pendingTreeDeltaItems = [];
        pendingNewExpandedKeys = [];
      } else if (
        dueToFlush &&
        pendingTreeDeltaItems.length > 0 &&
        p.widgetPanel &&
        lastStreamingFlatCount > 0
      ) {
        const W = Math.max(MIN_WIDTH, p.viewportWidth - 2);
        const flushed = pendingTreeDeltaItems;
        const flushedNewExp = pendingNewExpandedKeys;
        pendingTreeDeltaItems = [];
        pendingNewExpandedKeys = [];
        const newItemKeys = flushed.map(flatItemKey);
        const newNodes = withPanel(p, () => flatItemsToTreeNodes(flushed, newItemKeys, W));
        p.widgetPanel.appendTreeNodes("matchTree", newNodes, newItemKeys);
        lastStreamingFlatCount += flushed.length;
        lastUiFlush = nowMs;
        if (flushedNewExp.length > 0) {
          p.widgetPanel.setExpandedKeys(
            "matchTree",
            [...p.expandedFileKeys],
          );
        }
      } else if (lastStreamingFlatCount === 0 && p.fileGroups.length > 0) {
        // First time we have any results — mount the Tree via a full
        // p update. Subsequent batches use the cheap append path.
        // Also drain the pending buffer into the spec since
        // updatePanelContent rebuilds from `panel.fileGroups` directly.
        pendingTreeDeltaItems = [];
        pendingNewExpandedKeys = [];
        withPanel(p, updatePanelContent);
        lastStreamingFlatCount = p.fileGroups.length + p.searchResults.length;
        lastUiFlush = nowMs;
      }
      if (producerFinished) {
        // Streaming finished. The tree is already current in the host
        // via the per-batch `appendTreeNodes` mutations — its nodes
        // don't need refreshing. The only state that drifted is the
        // small chrome strings: the matchStats label next to the
        // input fields, and the "Matches (N in M files)" header in
        // the separator. Update them in place via `setRawEntries`
        // (a few-hundred-byte mutation) instead of re-emitting the
        // full p spec — the latter would force `js_to_json` over
        // every TreeNode (~447 bytes × 5 000 nodes = 2.2 MB) and
        // block the JS thread for ~1 second, exactly when user input
        // piles up unread in the request channel. See the
        // RESOLVE_CB_DONE dur_us=1095122 case in the perf trace.
        if (shown && p.widgetPanel) {
          if (p.fileGroups.length === 0) {
            // Special case: 0 matches. The matches body is an
            // empty-state `raw()`, not a `tree()` — we have to swap
            // widget kinds, which `setRawEntries` alone can't do.
            // The full re-emit here is cheap because the tree is
            // empty (no per-node serialization cost).
            withPanel(p, updatePanelContent);
          } else {
            const w = p.widgetPanel;
            withPanel(p, () => {
              w.setRawEntries("matchStats", buildMatchStatsEntries());
              w.setRawEntries("separator", buildPanelEntries("postOptions"));
            });
          }
        }
        lastStreamingFlatCount = 0;
        pendingTreeDeltaItems = [];
        pendingNewExpandedKeys = [];
      }
      // Also refresh the matchStats label on every streaming flush so
      // the count updates in real time as results stream in.
      if (shown && !producerFinished && dueToFlush && p.widgetPanel) {
        const w = p.widgetPanel;
        withPanel(p, () => {
          w.setRawEntries("matchStats", buildMatchStatsEntries());
          w.setRawEntries("separator", buildPanelEntries("postOptions"));
        });
      }

      if (producerFinished) {
        truncated = batchTruncated;
        producerError = batchError;
        break;
      }

      // Yield to the JS event loop between chunks. `delay(0)` is
      // enough — it lets queued plugin handlers (Tab, typed input,
      // Esc) run between our streaming work. When there's no
      // carryover, wait the usual pump interval so we don't hot-loop
      // on `handle.take()`.
      const yieldMs = moreInQueue ? 0 : SEARCH_PUMP_INTERVAL_MS;
      await editor.delay(yieldMs);
      buffersByPath = windowBuffersByPath(p.windowId);
    }

    if (p.searchHandle === handle) {
      p.searchHandle = null;
    }

    // Final state
    if (generation !== p.searchGeneration || panels.get(p.windowId) !== p) return allResults;

    if (producerError) {
      throw new Error(producerError);
    }

    p.truncated = truncated;

    // Status messages are per window: one for a background panel is held
    // until its window is back (`showStatusFor`).

    if (!silent) {
      if (allResults.length === 0) {
        showStatusFor(p, editor.t("status.no_matches", { pattern }));
      } else if (p.truncated) {
        showStatusFor(p, editor.t("status.found_matches", { count: String(allResults.length) }) + " " + editor.t("panel.limited"));
      } else {
        showStatusFor(p, editor.t("status.found_matches", { count: String(allResults.length) }));
      }
    }
    return allResults;
  } catch (e) {
    if (!silent) {
      showStatusFor(p, editor.t("status.search_error", { error: String(e) }));
    }
    return [];
  }
}

// =============================================================================
// Panel lifecycle
// =============================================================================

/** In-flight `openPanel` run, if any (#2953).
 *
 * `openPanel` awaits the host round-trip that creates the panel's virtual
 * buffer, and only learns the buffer id when that resolves. A second
 * invocation arriving inside that await — pressing `Alt+A` twice, or the
 * keymap and the palette firing together — used to see the half-built
 * `panel` object, take the "already open" branch and render the widget tree
 * into `resultsBufferId === 0`. The host has no buffer 0, so the mount
 * failed, the panel stayed bound to the bogus id and every later update
 * failed too: a panel with no search field, no replace field and no footer,
 * which never repaired itself.
 *
 * Opens are therefore serialized. A concurrent caller waits for the run
 * ahead of it and then applies its own intent (prefill, scope) to the
 * finished panel, so pressing the key twice ends up exactly where pressing
 * it twice slowly does. */
let openPanelInFlight: Promise<void> | null = null;

async function openPanel(opts?: { allFiles?: boolean }): Promise<void> {
  // Wait out any open already in progress (a chain of them, if the user
  // leaned on the key), then take the baton.
  while (openPanelInFlight) {
    await openPanelInFlight;
  }
  const run = openPanelInner(opts);
  openPanelInFlight = run;
  try {
    await run;
  } finally {
    if (openPanelInFlight === run) openPanelInFlight = null;
  }
}

async function openPanelInner(opts?: { allFiles?: boolean }): Promise<void> {
  // Try to pre-fill search from editor selection
  let prefill = "";
  let sourceBufferPath = "";
  let sourceBufferId = 0;
  try {
    const activeId = editor.getActiveBufferId();
    sourceBufferId = activeId;
    sourceBufferPath = editor.getBufferPath(activeId) || "";
    const cursor = editor.getPrimaryCursor();
    if (cursor && cursor.selection) {
      const start = Math.min(cursor.selection.start, cursor.selection.end);
      const end = Math.max(cursor.selection.start, cursor.selection.end);
      if (end - start > 0 && end - start < 200) {
        const text = await editor.getBufferText(activeId, start, end);
        if (text && !text.includes("\n")) {
          prefill = text;
        }
      }
    }
  } catch (_e) { /* no selection / no buffer */ }

  const allFiles = opts?.allFiles ?? true;
  const sourceBufferRelPath = sourceBufferPath ? getRelativePath(sourceBufferPath) : "";

  // `panel` is this window's panel; another window's is left alone.
  if (panel) {
    panel.focusPanel = "query";
    panel.queryField = "search";
    if (prefill) panel.searchPattern = prefill;
    panel.cursorPos = panel.searchPattern.length;
    // Re-opening from a different file/scope refreshes scope context.
    panel.allFiles = allFiles;
    panel.sourceBufferPath = sourceBufferPath;
    panel.sourceBufferRelPath = sourceBufferRelPath;
    panel.sourceBufferId = sourceBufferId;
    updatePanelContent();
    if (panel.searchPattern) rerunSearchDebounced();
    return;
  }

  const sourceSplitId = editor.getActiveSplitId();
  // The window the buffer is created in, should the user switch away while
  // the host creates it.
  const windowId = currentWindowId;

  try {
    // Create the buffer *before* publishing `panel`. Everything that reads
    // the module-level `panel` — the `resize` hook, `after_file_open`,
    // `updatePanelContent` — would otherwise be able to observe a panel
    // whose `resultsBufferId` is still the 0 placeholder and render the
    // widget tree into a buffer that does not exist (#2953). Assigning only
    // once the real id is in hand makes that state unrepresentable rather
    // than merely guarded against.
    const result = await editor.createVirtualBufferInSplit({
      name: "*Search/Replace*",
      mode: "search-replace-list",
      readOnly: true,
      // The panel's content is painted by `updatePanelContent()` below, as
      // a widget tree; the buffer starts empty for the one frame in between.
      entries: [],
      ratio: 0.6,
      panelId: "search-replace-panel",
      // Opt into the Utility Dock (issue #1796 / Section 2 of
      // docs/internal/tui-editor-layout-design.md). When the dock
      // already exists, the editor swaps the dock's active buffer
      // to the search-replace panel instead of spawning a new split.
      role: "utility_dock",
      showLineNumbers: false,
      showCursors: false,
      editingDisabled: true,
      // The panel manages its own scrolling (the match Tree owns its
      // scroll window), so the buffer must not be user-scrollable —
      // otherwise a scrollbar appears and dragging it scrolls the
      // search inputs off-screen, revealing empty space below (#2434).
      scrollable: false,
    });

    const created: PanelState = {
      windowId,
      root: editor.getCwd(),
      stale: false,
      staleKeepPosition: false,
      needsRedraw: false,
      searchGeneration: 0,
      searchHandle: null,
      debounceGeneration: 0,
      searchAfterEdit: null,
      replaceInProgress: false,
      pendingStatus: null,
      parked: null,
      resultsBufferId: result.bufferId,
      sourceSplitId,
      resultsSplitId: result.splitId ?? editor.getActiveSplitId(),
      searchResults: [],
      fileGroups: [],
      searchPattern: prefill,
      replaceText: "",
      fileGlob: "",
      focusPanel: "query",
      queryField: "search",
      optionIndex: 0,
      matchIndex: 0,
      caseSensitive: sessionMatchOptions.caseSensitive,
      useRegex: sessionMatchOptions.useRegex,
      wholeWords: sessionMatchOptions.wholeWords,
      allFiles,
      sourceBufferPath,
      sourceBufferRelPath,
      sourceBufferId,
      // Now we have the split, so the real width is available.
      viewportWidth: getViewportWidth(),
      busy: false,
      searchPerformed: false,
      truncated: false,
      cursorPos: prefill.length,
      scrollOffset: 0,
      expandedFileKeys: new Set<string>(),
      knownFileKeys: new Set<string>(),
      widgetPanel: null,
    };
    panels.set(windowId, created);
    editor.debug(`Search/Replace: panel opened, bufferId=${result.bufferId}, splitId=${result.splitId}`);

    if (windowId !== currentWindowId) {
      // The user left the window while its panel was being created: draw it
      // when they come back.
      created.stale = true;
      return;
    }
    panel = created;
    updatePanelContent();
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    editor.setStatus(editor.t("status.failed_open_panel"));
    editor.debug(`ERROR: createVirtualBufferInSplit failed: ${errorMessage}`);
  }
}

// =============================================================================
// Replacements
// =============================================================================

/** Files the last replace rewrote. An undo there puts the replaced matches
 *  back, so the panel re-runs its search when one of them changes (see the
 *  `buffer_modified` handler). Cleared when the panel closes. */
let lastReplacedFiles = new Set<string>();

async function executeReplacements(results?: SearchResult[]): Promise<string> {
  const p = panel;
  if (!p) return "";
  const toReplace = results || p.searchResults.filter(r => r.selected);
  if (toReplace.length === 0) {
    return editor.t("status.no_selected");
  }

  // Group edits per target. Matches in an open buffer carry a non-zero
  // bufferId; key by it so an unnamed buffer (whose `file` is a shared
  // "[No Name]" label) still resolves to the right buffer rather than
  // colliding with another unnamed buffer's matches. On-disk files
  // (bufferId 0) key by path and are opened/saved by the host as before.
  type Group = { filePath: string; bufferId: number; matches: Array<[number, number]> };
  const groups: Map<string, Group> = new Map();
  for (const result of toReplace) {
    const bufferId = result.match.bufferId || 0;
    const key = bufferId > 0 ? `buf:${bufferId}` : result.match.file;
    let group = groups.get(key);
    if (!group) {
      group = { filePath: result.match.file, bufferId, matches: [] };
      groups.set(key, group);
    }
    group.matches.push([result.match.byteOffset, result.match.length]);
  }

  let filesModified = 0;
  let replacementsCount = 0;
  const errors: string[] = [];

  // In regex mode the replacement is a template (`$1`, `${name}`, `\n`);
  // the host expands it per match against the search that found it.
  const regex = p.useRegex
    ? { pattern: p.searchPattern, caseSensitive: p.caseSensitive, wholeWords: p.wholeWords }
    : undefined;

  const groupList: Group[] = [];
  groups.forEach((g) => groupList.push(g));
  lastReplacedFiles = new Set(groupList.map((g) => g.filePath));
  let interrupted = false;
  for (const group of groupList) {
    // The host rewrites files and buffers of the active window. Once the
    // user has switched windows, the rest of these belong to a window that
    // is no longer active: stop. The panel re-searches when its window is
    // back (`rerunSearchQuiet` defers a search it can't start here).
    if (panel !== p) {
      interrupted = true;
      break;
    }
    try {
      const result = await editor.replaceInFile(
        group.filePath,
        group.matches,
        p.replaceText,
        group.bufferId,
        regex
      );
      replacementsCount += result.replacements;
      if (result.replacements > 0) filesModified++;
    } catch (e) {
      errors.push(`${group.filePath}: ${e instanceof Error ? e.message : String(e)}`);
    }
  }

  if (interrupted) {
    // Said in the panel's window when the user is back there (the caller
    // holds the message), so a partial replace is never silent.
    return editor.t("status.replace_interrupted", {
      count: String(replacementsCount),
      files: String(filesModified),
      total: String(groupList.length),
    });
  }
  if (errors.length > 0) {
    editor.debug(`Replacement errors: ${errors.join(", ")}`);
    return editor.t("status.replaced_with_errors", { files: String(filesModified), errors: String(errors.length) });
  }
  return editor.t("status.replaced", { count: String(replacementsCount), files: String(filesModified) });
}

// =============================================================================
// Re-search
// =============================================================================

/** The match the user had stepped onto when an edit re-ran the search
 *  (`buffer_modified`), so stepping goes on from it rather than starting over
 *  at the first match. Held by a marker of its own while the re-search runs:
 *  each keystroke of the edit starts another re-search, and the edits made in
 *  the meantime must shift it too. A match in a file that isn't open has no
 *  marker; its file can't be edited, so its grep position stands. */
type ResumeAnchor = { file: string; byte: number; bufferId?: number; key?: string };
let resumeAnchor: ResumeAnchor | null = null;

/** Anchor the match at the panel's selection, unless an earlier re-search
 *  still holds an anchor — the selection was reset when that one started. */
function anchorSteppedMatch(): void {
  if (!panel || resumeAnchor) return;
  const item = buildFlatItems()[panel.matchIndex];
  if (!item || item.type !== "match") return;
  const result = panel.fileGroups[item.fileIndex].matches[item.matchIndex!];
  let byte = result.match.byteOffset;
  if (result.markerKey && result.markerBufferId) {
    const marker = editor.getMarker(result.markerBufferId, result.markerKey) as
      | { start: number }
      | null;
    if (marker && typeof marker.start === "number") byte = marker.start;
  }
  resumeAnchor = { file: result.match.file, byte };
  const key = `sr:${nextMatchMarkerId++}`;
  if (result.markerBufferId && editor.createMarker(result.markerBufferId, key, byte, byte + result.match.length, null)) {
    resumeAnchor.bufferId = result.markerBufferId;
    resumeAnchor.key = key;
  }
}

/** Forget the anchor, returning where its match is now. */
function takeResumeAnchor(): { file: string; byte: number } | null {
  const anchor = resumeAnchor;
  resumeAnchor = null;
  if (!anchor) return null;
  if (anchor.bufferId && anchor.key) {
    const marker = editor.getMarker(anchor.bufferId, anchor.key) as { start: number } | null;
    if (marker && typeof marker.start === "number") anchor.byte = marker.start;
    editor.deleteMarker(anchor.bufferId, anchor.key);
  }
  return { file: anchor.file, byte: anchor.byte };
}

/** The row to step on from: the match now at `at`, else the last one before
 *  it in its file, else that file's header row — so the next step lands on the
 *  first match after `at` either way. The top of the list when its file has no
 *  matches left. */
function flatIndexAtLocation(at: { file: string; byte: number }): number {
  if (!panel) return 0;
  const flat = buildFlatItems();
  let found = 0;
  for (let i = 0; i < flat.length; i++) {
    const item = flat[i];
    const group = panel.fileGroups[item.fileIndex];
    if (group.absPath !== at.file) continue;
    if (item.type === "match" && group.matches[item.matchIndex!].match.byteOffset > at.byte) {
      break;
    }
    found = i;
  }
  return found;
}


/** Re-run the search. `keepPosition` is for the re-search an edit starts:
 *  the user did not ask for it, so their place in the results survives it.
 *
 *  Runs for the active window's panel and finishes for that panel even if
 *  the user switches windows meanwhile: the search keeps going in the
 *  background and the panel is drawn when its window is back. */
async function rerunSearch(keepPosition = false): Promise<void> {
  const p = panel;
  if (!p || !p.searchPattern) return;
  // No `busy` early-return: if a search is already running for an older
  // pattern (e.g. user typed "pr" then "proj"), the newer search starts
  // NOW, not after the old one finishes walking the project.
  // `performSearch` bumps the panel's search generation and cancels the
  // prior handle; the older in-flight search sees the mismatch on its next
  // pump tick and bails out without writing to panel state.
  p.debounceGeneration++;
  // The generation this rerunSearch will own once performSearch increments
  // it. If a newer search of this panel slots in while we're awaiting, the
  // generation moves past `myGen` and this stale invocation doesn't
  // finalize busy/searchPerformed.
  const myGen = p.searchGeneration + 1;
  if (keepPosition) anchorSteppedMatch();
  else takeResumeAnchor();
  p.truncated = false;
  p.busy = true;
  p.matchIndex = 0;
  p.scrollOffset = 0;
  await performSearch(p, p.searchPattern);
  if (p.searchGeneration !== myGen || panels.get(p.windowId) !== p) return;
  // performSearch maintained searchResults / fileGroups incrementally while
  // streaming and pushed matchStats / separator updates via cheap targeted
  // mutations. What's left: final flags, the sort, and one re-emit.
  p.busy = false;
  p.searchPerformed = true;
  // The tree was built in file-arrival order while streaming; re-order the
  // file groups into natural path order so the reviewer sees a stable,
  // sorted list (#2435).
  if (p.searchResults.length > 0) withPanel(p, sortFileGroups);
  if (p !== panel) {
    // Finished in the background: the resume position (parked with the
    // panel) and the redraw are applied when its window is back.
    p.needsRedraw = true;
    return;
  }
  if (p.widgetPanel) {
    // The only full re-emit of the run — after streaming has stopped, so it
    // doesn't compete with input the way per-batch re-emits would. With
    // zero matches it is also what replaces the "Searching…" body (last
    // drawn while `busy` was true) with "No matches"; cheap then, the tree
    // being empty.
    const resumeAt = takeResumeAnchor();
    if (resumeAt && p.searchResults.length > 0) p.matchIndex = flatIndexAtLocation(resumeAt);
    updatePanelContent();
  }
}

function rerunSearchDebounced(keepPosition = false): void {
  const owner = panel;
  if (!owner) return;
  const gen = ++owner.debounceGeneration;
  editor.delay(SEARCH_DEBOUNCE_MS).then(() => {
    if (gen !== owner.debounceGeneration) return;
    if (panel !== owner) {
      // Asked for in a window the user has since left: run it when that
      // window is back.
      owner.stale = true;
      owner.staleKeepPosition = owner.staleKeepPosition || keepPosition;
      return;
    }
    const run = rerunSearch(keepPosition);
    if (!keepPosition) return;
    owner.searchAfterEdit = run;
    run.finally(() => {
      if (owner.searchAfterEdit === run) owner.searchAfterEdit = null;
    });
  });
}

// Same as rerunSearch but doesn't update status bar (preserves replacement
// message), and for a given panel, which may be in the background by now.
async function rerunSearchQuiet(p: PanelState | null = panel): Promise<void> {
  if (!p || !p.searchPattern) return;
  if (p !== panel) {
    // The host searches the *active* window's project, so a search can't be
    // started for a panel in the background (one already running keeps its
    // own). Run it when the panel's window is back.
    p.stale = true;
    p.needsRedraw = false;
    return;
  }
  if (p.busy) return;
  p.debounceGeneration++;
  p.busy = true;
  const myGen = p.searchGeneration + 1;
  const results = await performSearch(p, p.searchPattern, true);
  if (p.searchGeneration !== myGen || panels.get(p.windowId) !== p) return;
  p.searchResults = results;
  p.fileGroups = withPanel(p, () => buildFileGroups(results));
  p.matchIndex = 0;
  p.scrollOffset = 0;
  p.busy = false;
  p.searchPerformed = true;
  if (p === panel) updatePanelContent();
  else p.needsRedraw = true;
}

// =============================================================================
// Text editing handlers (inline editing of query fields)
// =============================================================================

// ↓ in the search field that is not walking history goes on to the
// host's own arrow handling (into the match tree): the binding owns the
// key on that field, so it hands it back explicitly.
function dispatch(action: WidgetAction): void {
  panel?.widgetPanel?.command(action);
}

/** Apply a stored history entry to the search field. Mutates the
 *  widget's value via setValue so the host instance state stays in
 *  sync with the plugin's panel.searchPattern, and triggers a
 *  debounced re-search. See §11. */
function applyHistoryEntry(text: string): void {
  if (!panel || !panel.widgetPanel) return;
  panel.searchPattern = text;
  panel.cursorPos = text.length;
  panel.searchPerformed = false;
  panel.widgetPanel.setValue("searchField", text, byteLen(text));
  rerunSearchDebounced();
}

// Bound only on the search field (`on:searchField`): everywhere else ↑/↓
// are the focused control's, or the host's spatial move.
registerHandler("search_replace_nav_up", () => {
  if (!panel || searchHistory.length === 0) return;
  if (historyIndex < 0) {
    // Entering history walk — snapshot what the user had typed so
    // a Down past the most recent entry restores it.
    historySavedPattern = panel.searchPattern;
    historyIndex = 0;
  } else if (historyIndex < searchHistory.length - 1) {
    historyIndex += 1;
  } else {
    return; // already at the oldest entry
  }
  applyHistoryEntry(searchHistory[historyIndex]);
});
registerHandler("search_replace_nav_down", () => {
  if (!panel) return;
  if (historyIndex >= 0) {
    if (historyIndex > 0) {
      historyIndex -= 1;
      applyHistoryEntry(searchHistory[historyIndex]);
      return;
    }
    // Down past the most recent entry → exit history walk and restore
    // whatever the user had typed before they hit Up.
    historyIndex = -1;
    const restore = historySavedPattern ?? "";
    historySavedPattern = null;
    applyHistoryEntry(restore);
    return;
  }
  dispatch(widgetKey("Down"));
});
// Global option toggles (Alt+C, Alt+R, Alt+W)
function search_replace_toggle_case(): void {
  if (!panel) return;
  panel.caseSensitive = !panel.caseSensitive;
  sessionMatchOptions.caseSensitive = panel.caseSensitive;
  updatePanelContent();
  rerunSearchDebounced();
}
registerHandler("search_replace_toggle_case", search_replace_toggle_case);

function search_replace_toggle_regex(): void {
  if (!panel) return;
  panel.useRegex = !panel.useRegex;
  sessionMatchOptions.useRegex = panel.useRegex;
  updatePanelContent();
  rerunSearchDebounced();
}
registerHandler("search_replace_toggle_regex", search_replace_toggle_regex);

function search_replace_toggle_whole_word(): void {
  if (!panel) return;
  panel.wholeWords = !panel.wholeWords;
  sessionMatchOptions.wholeWords = panel.wholeWords;
  updatePanelContent();
  rerunSearchDebounced();
}
registerHandler("search_replace_toggle_whole_word", search_replace_toggle_whole_word);

function search_replace_replace_all(): void {
  doReplaceAll();
}
registerHandler("search_replace_replace_all", search_replace_replace_all);

function search_replace_replace_scoped(): void {
  doReplaceScoped();
}
registerHandler("search_replace_replace_scoped", search_replace_replace_scoped);

// =============================================================================
// Action handlers
// =============================================================================

// =============================================================================
// Replace confirmation dialog
// =============================================================================
//
// Replacements write to disk immediately and Undo only covers files that
// stay open, so a replace asks first. It used to ask on the prompt line at
// the bottom of the screen, which was easy to miss; this is a modal dialog
// centred on the screen instead. Enter replaces (focus starts on Replace),
// Esc / Cancel / the [×] back out.

let confirmDialog: { panel: FloatingWidgetPanel; resolve: (ok: boolean) => void } | null = null;

function confirmReplace(count: number, files: number): Promise<boolean> {
  settleConfirmDialog(false);
  return new Promise((resolve) => {
    const dialog = new FloatingWidgetPanel();
    confirmDialog = { panel: dialog, resolve };
    dialog.mount(
      col(
        spacer(0),
        label(" " + editor.t("dialog.confirm_replace_body", {
          count: String(count),
          files: String(files),
        }), { wrap: true }),
        label(" " + editor.t("dialog.confirm_replace_undo_note"), {
          wrap: true,
          style: { fg: C.label, italic: true },
        }),
        spacer(0),
        row(
          flexSpacer(),
          button(editor.t("dialog.cancel_btn"), { key: "confirmCancel" }),
          spacer(2),
          button(editor.t("dialog.confirm_replace_btn"), { intent: "primary", key: "confirmReplace" }),
          spacer(1),
        ),
      ),
      {
        widthPct: 50,
        heightPct: 30,
        focusMarker: true,
        title: editor.t("dialog.confirm_replace_title"),
        closable: true,
      },
    );
    // Centre on the whole screen, not just the area beside the dock.
    editor.floatingPanelControl(dialog.id(), "fullscreen", 1);
    dialog.setFocusKey("confirmReplace");
  });
}

/** Resolve the open confirmation, if any. `unmount` is false when the host
 *  has already taken the dialog down (Esc, click outside, the [×]). */
function settleConfirmDialog(ok: boolean, unmount = true): void {
  if (!confirmDialog) return;
  const { panel: dialog, resolve } = confirmDialog;
  confirmDialog = null;
  if (unmount) dialog.unmount();
  resolve(ok);
}

/** Lock against re-entrant Replace All / Replace Scoped. Set as soon
 *  as doReplaceAll/doReplaceScoped enters and cleared in a try/finally
 *  around the whole flow. Without this, a user mashing Alt+Enter
 *  during a streaming search produces N stacked confirmation prompts
 *  once the search finishes — the host queues each keystroke and
 *  drains them all when the JS event loop frees up; by then
 *  `panel.busy` is false so the busy guard doesn't fire. */

async function doReplaceAll(): Promise<void> {
  if (!panel) return;
  if (panel.busy) {
    // Search is still streaming. Don't block silently — tell the user
    // to wait, and don't queue the replace. (The host's event
    // dispatcher would otherwise hold the keystroke and run it when
    // the pump finishes, which feels like an unexplained delay.)
    editor.setStatus(editor.t("status.replace_wait_for_search"));
    return;
  }
  if (panel.replaceInProgress) {
    // First Alt+Enter is already showing its prompt or running the
    // rewrites. Drop the duplicate so we don't stack prompts.
    return;
  }
  const owner = panel;
  owner.replaceInProgress = true;
  try {
    await doReplaceAllInner();
  } finally {
    owner.replaceInProgress = false;
  }
}

async function doReplaceAllInner(): Promise<void> {
  if (!panel) return;
  const selected = panel.searchResults.filter(r => r.selected);
  if (selected.length === 0) {
    editor.setStatus(editor.t("status.no_items_selected"));
    return;
  }
  // The user committed to this pattern by triggering Replace All —
  // a clear "settle" signal, so commit it to history now even if the
  // 2s scheduleHistoryPush hasn't fired yet.
  if (historyIndex < 0) historyPush(panel.searchPattern);
  // Confirm before applying.  Replacements write to disk immediately; Undo
  // only covers files that remain open in this session (see bug #1 report).
  const fileCount = new Set(selected.map(r => r.match.file)).size;
  const owner = panel;
  if (!await confirmReplace(selected.length, fileCount)) {
    if (panel === owner) editor.setStatus(editor.t("status.replace_cancelled"));
    return;
  }
  if (!panel || panel !== owner) return;
  panel.busy = true;
  editor.setStatus(editor.t("status.replacing", { count: String(selected.length) }));
  const statusMsg = await executeReplacements(selected);
  showStatusFor(owner, statusMsg);
  // Clear stale results before re-searching: the byte offsets in
  // `panel.searchResults` now point at positions in the pre-replacement
  // file and must never be re-used (see bug #4 — a second Alt+Enter would
  // otherwise corrupt files by writing into moved offsets).  We also drop
  // `busy` so rerunSearchQuiet doesn't bail out on its own guard.
  withPanel(owner, clearMatchMarkers);
  owner.searchResults = [];
  owner.fileGroups = [];
  owner.busy = false;
  await rerunSearchQuiet(owner);
  if (panel === owner) updatePanelContent();
}

async function doReplaceScoped(): Promise<void> {
  if (!panel || panel.focusPanel !== "matches") return;
  if (panel.busy) {
    editor.setStatus(editor.t("status.replace_wait_for_search"));
    return;
  }
  if (panel.replaceInProgress) return;
  const owner = panel;
  owner.replaceInProgress = true;
  try {
    await doReplaceScopedInner();
  } finally {
    owner.replaceInProgress = false;
  }
}

async function doReplaceScopedInner(): Promise<void> {
  if (!panel) return;
  const flat = buildFlatItems();
  const item = flat[panel.matchIndex];
  if (!item) return;

  let toReplace: SearchResult[] = [];
  if (item.type === "file") {
    toReplace = panel.fileGroups[item.fileIndex].matches.filter(m => m.selected);
  } else {
    const result = panel.fileGroups[item.fileIndex].matches[item.matchIndex!];
    if (result.selected) toReplace = [result];
  }
  // Same as doReplaceAll: explicit commit, push immediately.
  if (historyIndex < 0) historyPush(panel.searchPattern);

  if (toReplace.length === 0) {
    editor.setStatus(editor.t("status.no_selected"));
    return;
  }

  const fileCount = new Set(toReplace.map(r => r.match.file)).size;
  const owner = panel;
  if (!await confirmReplace(toReplace.length, fileCount)) {
    if (panel === owner) editor.setStatus(editor.t("status.replace_cancelled"));
    return;
  }
  if (!panel || panel !== owner) return;

  panel.busy = true;
  editor.setStatus(editor.t("status.replacing", { count: String(toReplace.length) }));
  const statusMsg = await executeReplacements(toReplace);
  showStatusFor(owner, statusMsg);
  // See doReplaceAll — clear stale offsets and drop busy before re-searching.
  withPanel(owner, clearMatchMarkers);
  owner.searchResults = [];
  owner.fileGroups = [];
  owner.busy = false;
  await rerunSearchQuiet(owner);
  if (panel === owner) updatePanelContent();
}

// =============================================================================
// Match navigation (issue #2434)
// =============================================================================
//
// Reviewing a large result set match-by-match used to cost three
// keystrokes each: Down (select the next row in the panel), Enter
// (open it in the editor — which moves focus to the source split), and
// Alt+] to return to the panel before repeating. These two commands
// collapse that to a single keystroke usable *from the editor*: advance
// the panel's selection to the next/previous match row, open it in the
// source split (cursor lands on the match, ready to edit), and leave
// focus where it is. Press again to move to the next one. Mirrors the
// next/prev idiom in diff_nav.ts.

/** 1-based ordinal of the match row at flat index `flatIdx` among all
 *  match rows (file-header rows don't count). Used for "Match n/total"
 *  status feedback. */
function matchOrdinal(flat: FlatItem[], flatIdx: number): number {
  let count = 0;
  for (let i = 0; i <= flatIdx && i < flat.length; i++) {
    if (flat[i].type === "match") count++;
  }
  return count;
}

/** Flat index of the next (dir=1) / previous (dir=-1) match row
 *  relative to `from`, skipping file-header rows and wrapping around.
 *  Returns -1 when there are no match rows at all. */
function adjacentMatchIndex(flat: FlatItem[], from: number, dir: 1 | -1): number {
  const n = flat.length;
  if (n === 0) return -1;
  // Normalize the start so the first step lands on a real neighbour
  // even when `from` is out of range or sits on a file header.
  let start = from;
  if (start < 0 || start >= n) start = dir === 1 ? -1 : n;
  for (let step = 1; step <= n; step++) {
    const idx = (((start + dir * step) % n) + n) % n;
    if (flat[idx].type === "match") return idx;
  }
  return -1;
}

// =============================================================================
// Anchor match positions to buffer edits with interval markers (issue #2583)
//
// A match's line/column/byteOffset are captured once, at grep time. The
// "step through matches and edit each" workflow (#2434) edits the buffer
// between steps, so without anchoring the cursor lands on stale pre-edit
// positions. Rather than re-deriving edit deltas in the plugin — which
// can't even see bulk edits: paste, multi-cursor, type-over-selection,
// query-replace and LSP code-action rewrites apply as a single BulkEdit
// that bypasses the after_insert/after_delete hooks — we register an
// interval marker at each match's byte range in its open buffer. The editor
// keeps the marker shifted across *every* edit kind (the CoordMap mechanism
// that markdown_compose and #2602's diagnostics also ride). At jump time we
// read the marker's live start byte and convert it back to (line, column).
//
// Matches in files that aren't open have no buffer to anchor to, but they
// also can't be edited, so their grep positions stay valid as a fallback.
// =============================================================================

let nextMatchMarkerId = 0;

/** Register an interval marker for `result` when its file is open and it has
 *  no marker yet. The marker spans the match's byte range; the editor keeps
 *  it shifted. No-op for closed files (no buffer to anchor to). */
function ensureMatchMarker(result: SearchResult, buffersByPath: Map<string, number>): void {
  if (result.markerKey) return;
  const bid = result.match.bufferId || buffersByPath.get(result.match.file);
  if (!bid || bid <= 0) return;
  const start = result.match.byteOffset;
  const key = `sr:${nextMatchMarkerId++}`;
  if (editor.createMarker(bid, key, start, start + result.match.length, null)) {
    result.markerKey = key;
    result.markerBufferId = bid;
  }
}

/** Register markers for every match in a file's buffer — used when a file is
 *  opened after the search captured it, so later edits to it still track. */
function ensureMarkersForPath(p: PanelState, path: string, bufferId: number): void {
  if (!path) return;
  const byPath = new Map([[path, bufferId]]);
  for (const r of p.searchResults) {
    if (r.match.file === path) ensureMatchMarker(r, byPath);
  }
}

/** Delete every marker we created and forget the keys. Called whenever the
 *  result set is torn down (re-search, panel close) so markers never leak.
 *  (The editor also drops a buffer's markers when it closes.) */
function clearMatchMarkers(): void {
  if (!panel) return;
  for (const r of panel.searchResults) {
    if (r.markerKey && r.markerBufferId) {
      editor.deleteMarker(r.markerBufferId, r.markerKey);
    }
    r.markerKey = undefined;
    r.markerBufferId = undefined;
  }
}

/** Convert a byte offset in `bufferId` to a 1-indexed (line, column), where
 *  column is a 1-indexed *byte* column — matching how grep produces positions
 *  (`column = byteOffset - lineStart + 1`), so it round-trips through
 *  `openFileInSplit` unchanged, including for multibyte content. */
async function byteOffsetToLineColumn(
  bufferId: number,
  offset: number,
): Promise<{ line: number; column: number }> {
  const prefix = await editor.getBufferText(bufferId, 0, offset);
  let line = 1;
  let lastNewline = -1;
  for (let i = 0; i < prefix.length; i++) {
    if (prefix.charCodeAt(i) === 10) {
      line++;
      lastNewline = i;
    }
  }
  const column = byteLen(prefix.slice(lastNewline + 1)) + 1;
  return { line, column };
}

/** Resolve a match to its *current* (line, column): the live marker position
 *  when the buffer is open, else the grep position. Writes the resolved value
 *  back onto the match so panel rows show the shifted line number on the next
 *  render too. */
async function resolveMatchTarget(
  result: SearchResult,
): Promise<{ line: number; column: number }> {
  if (result.markerKey && result.markerBufferId) {
    const marker = editor.getMarker(result.markerBufferId, result.markerKey) as
      | { start: number }
      | null;
    if (marker && typeof marker.start === "number") {
      const pos = await byteOffsetToLineColumn(result.markerBufferId, marker.start);
      result.match.line = pos.line;
      result.match.column = pos.column;
      return pos;
    }
  }
  return { line: result.match.line, column: result.match.column };
}

/** Open a match in the source split at its current (edit-tracked) position. */
async function openResultLocation(result: SearchResult): Promise<void> {
  if (!panel) return;
  const { line, column } = await resolveMatchTarget(result);
  editor.openFileInSplit(panel.sourceSplitId, result.match.file, line, column);
}

/** Open the match at flat index `flatIdx` in the source split and sync
 *  the panel's selection/expansion so the row is highlighted and
 *  scrolled into view. `openFileInSplit` focuses the source split, so
 *  the user can edit the match immediately and press the nav key again
 *  to move on — no detour back through the panel. */
async function jumpToMatch(flat: FlatItem[], flatIdx: number): Promise<void> {
  if (!panel) return;
  const item = flat[flatIdx];
  if (!item || item.type !== "match") return;
  panel.matchIndex = flatIdx;
  // Keep the selection meaningful for a subsequent full re-render and
  // for Shift+Enter (replace-scoped), which both key off focusPanel.
  panel.focusPanel = "matches";
  // Ensure the file group is expanded so the selected row is visible.
  const fileKey = `file:${item.fileIndex}`;
  panel.expandedFileKeys.add(fileKey);
  if (panel.widgetPanel) {
    panel.widgetPanel.setExpandedKeys("matchTree", [...panel.expandedFileKeys]);
    panel.widgetPanel.setSelectedIndex("matchTree", flatIdx);
  }
  // Opening a result is a clear "this is the search I wanted" signal —
  // commit the pattern to history (matches the Enter/activate path).
  if (historyIndex < 0) historyPush(panel.searchPattern);
  const group = panel.fileGroups[item.fileIndex];
  const result = group.matches[item.matchIndex!];
  await openResultLocation(result);
}

function navigateMatch(dir: 1 | -1): void {
  const waitFor = panel?.searchAfterEdit;
  if (waitFor) {
    // This window's own re-search; a step is dropped if the user has left
    // the window by the time it lands.
    const p = panel;
    waitFor.then(() => {
      if (panel === p) navigateMatch(dir);
    });
    return;
  }
  if (!panel || panel.searchResults.length === 0) {
    editor.setStatus(
      editor.t(panel?.busy ? "panel.searching" : "status.no_active_search"),
    );
    return;
  }
  const flat = buildFlatItems();
  const idx = adjacentMatchIndex(flat, panel.matchIndex, dir);
  if (idx < 0) {
    editor.setStatus(editor.t("status.no_active_search"));
    return;
  }
  // The panel selection updates synchronously (inside jumpToMatch, before its
  // first await); the source-split cursor lands a tick later once the marker
  // position is resolved. Status reflects the target immediately either way.
  jumpToMatch(flat, idx).catch((e) => editor.error(`search-replace: ${e}`));
  editor.setStatus(editor.t("status.match_position", {
    n: String(matchOrdinal(flat, idx)),
    total: String(panel.searchResults.length),
  }));
}

function search_replace_next_match(): void {
  navigateMatch(1);
}
registerHandler("search_replace_next_match", search_replace_next_match);

function search_replace_prev_match(): void {
  navigateMatch(-1);
}
registerHandler("search_replace_prev_match", search_replace_prev_match);

// Act on a tree row at flat index `idx`: open a match in the source
// split, or toggle a file header's expansion. Shared by Enter/activate
// on the tree and a mouse click on a row (issue #2434 follow-up: a
// click on a result should jump to it, just like Enter).
async function activateTreeItem(idx: number): Promise<void> {
  if (!panel) return;
  const flat = buildFlatItems();
  const item = flat[idx];
  if (!item) return;
  if (item.type === "file") {
    const k = `file:${item.fileIndex}`;
    if (panel.expandedFileKeys.has(k)) {
      panel.expandedFileKeys.delete(k);
    } else {
      panel.expandedFileKeys.add(k);
    }
    panel.widgetPanel?.setExpandedKeys("matchTree", [...panel.expandedFileKeys]);
  } else {
    // Opening a result is a "this is the search I wanted" signal —
    // commit it to history immediately, regardless of how long the
    // pattern has been stable. See §11 follow-up.
    if (historyIndex < 0) historyPush(panel.searchPattern);
    const group = panel.fileGroups[item.fileIndex];
    const result = group.matches[item.matchIndex!];
    await openResultLocation(result);
  }
}

function search_replace_close(): void {
  if (!panel) return;
  // If the user actually ran a search to completion with this
  // pattern (results were observed) and isn't walking history,
  // treat panel-close as a settle and commit to history. The
  // searchPerformed guard avoids capturing half-typed patterns
  // that never made it past the empty-state.
  if (
    historyIndex < 0
    && panel.searchPattern
    && panel.searchPerformed
  ) {
    historyPush(panel.searchPattern);
  }
  // Drop the anchor markers we registered on the source buffers so they
  // don't linger after the panel is gone.
  clearMatchMarkers();
  takeResumeAnchor();
  const sourceSplitId = panel.sourceSplitId;
  panel.widgetPanel?.unmount();
  editor.closeBuffer(panel.resultsBufferId);
  if (panel.resultsSplitId !== panel.sourceSplitId) {
    editor.closeSplit(panel.resultsSplitId);
  }
  forgetPanel(panel);
  // Restore focus to the split the user came from. Without this,
  // `getActiveBufferId()` on the next invocation can return the
  // utility dock's leftover buffer, and the §1 current-file scope
  // shows "(unsaved buffer)" instead of the real filename.
  editor.focusSplit(sourceSplitId);
  editor.setStatus(editor.t("status.closed"));
}

/** Show `msg` in `p`'s window: now if it is the active one, else when the
 *  user is back there (status messages are per window). */
function showStatusFor(p: PanelState, msg: string): void {
  if (panel === p) editor.setStatus(msg);
  else p.pendingStatus = msg;
}

/** Drop `p` from the per-window table, and its window-local context with it
 *  when it is the active window's panel. */
function forgetPanel(p: PanelState): void {
  // Stop its search, and drop its anchors: the active panel's are dropped by
  // the callers, a background panel's (and its parked resume anchor) here.
  p.searchGeneration++;
  if (p.searchHandle) {
    try { p.searchHandle.cancel(); } catch (_e) { /* ignore */ }
    p.searchHandle = null;
  }
  if (panel !== p) {
    withPanel(p, clearMatchMarkers);
    const anchor = p.parked?.resumeAnchor;
    if (anchor?.bufferId && anchor.key) editor.deleteMarker(anchor.bufferId, anchor.key);
    p.parked = null;
  }
  if (panels.get(p.windowId) === p) panels.delete(p.windowId);
  if (panel === p) {
    panel = null;
    settleConfirmDialog(false);
    lastReplacedFiles.clear();
  }
}
registerHandler("search_replace_close", search_replace_close);

// =============================================================================
// Command entry point
// =============================================================================

function start_search_replace(): void {
  openPanel();
}
registerHandler("start_search_replace", start_search_replace);

// §1: open the panel with scope already restricted to the active
// buffer. Useful when the user wants single-file search/replace from
// the keymap without flipping the toggle by hand.
function start_search_replace_in_buffer(): void {
  openPanel({ allFiles: false });
}
registerHandler("start_search_replace_in_buffer", start_search_replace_in_buffer);

// =============================================================================
// Event handlers (resize updates width)
// =============================================================================



editor.on("resize", (data) => {
  if (!panel) return;
  // Try viewport first (gives actual split width), fall back to terminal width estimate
  const vp = editor.getViewport();
  if (vp && vp.width > 0) {
    panel.viewportWidth = vp.width;
  } else {
    // Approximate: panel split is ~40% of terminal (ratio=0.6 means source gets 60%)
    panel.viewportWidth = Math.floor(data.width * 0.4);
  }
  updatePanelContent();
});

// Prompt handlers (in case prompts are opened externally for this panel - gracefully handle)

editor.on("prompt_cancelled", (args) => {
  if (!args.prompt_type.startsWith("search-replace-")) return true;
  return true;
});

// If the panel's virtual buffer is closed externally (via the × button,
// the Close Buffer/Close Tab commands, or anything else), reset the
// plugin's internal state so the next invocation of `openPanel` creates
// a fresh buffer/split instead of trying to update a buffer that no
// longer exists (which silently no-ops and leaves the user with no UI).

editor.on("buffer_closed", (args) => {
  if (panel && args.buffer_id === panel.resultsBufferId) {
    // The results buffer went away → tear down. Drop our anchor markers on
    // the (still-open) source buffers first so they don't leak.
    clearMatchMarkers();
    takeResumeAnchor();
    panel.widgetPanel?.unmount();
    forgetPanel(panel);
    return;
  }
  // A background window's panel buffer (closed along with its window).
  for (const p of panels.values()) {
    if (p.resultsBufferId === args.buffer_id) forgetPanel(p);
  }
});

editor.on("window_closed", (args) => {
  const p = panels.get(args.id);
  if (p) forgetPanel(p);
});

// Each window keeps its own panel (#3704). A search in the window being left
// keeps running for its own panel, which collects results without drawing
// (only the active window is drawn); the panel being returned to picks up
// where it was, drawing whatever arrived meanwhile.
editor.on("active_window_changed", (args) => {
  const outgoing = panel;
  if (outgoing) {
    outgoing.parked = { resumeAnchor, replacedFiles: lastReplacedFiles };
  }
  // The confirm dialog floats over the window being left.
  settleConfirmDialog(false);

  currentWindowId = args.active_id;
  panel = panels.get(currentWindowId) ?? null;
  resumeAnchor = panel?.parked?.resumeAnchor ?? null;
  lastReplacedFiles = panel?.parked?.replacedFiles ?? new Set<string>();
  if (!panel) return;
  panel.parked = null;
  if (panel.pendingStatus) {
    editor.setStatus(panel.pendingStatus);
    panel.pendingStatus = null;
  }
  if (panel.stale) {
    // A re-search was asked for while the window was in the background.
    const keepPosition = panel.staleKeepPosition;
    panel.stale = false;
    panel.staleKeepPosition = false;
    panel.needsRedraw = false;
    if (panel.searchPattern) void rerunSearch(keepPosition);
    else updatePanelContent();
  } else if (panel.needsRedraw && !panel.busy) {
    // A search finished in the background. (One still running redraws
    // itself on its next pump tick.)
    panel.needsRedraw = false;
    const resumeAt = takeResumeAnchor();
    if (resumeAt && panel.searchResults.length > 0) panel.matchIndex = flatIndexAtLocation(resumeAt);
    updatePanelContent();
  } else if (!panel.busy && getViewportWidth() !== panel.viewportWidth) {
    // The terminal was resized while the window was in the background; the
    // `resize` hook only redrew the active window's panel.
    updatePanelContent();
  }
});

// When a file is opened after the search captured it (e.g. the user steps
// into a result whose file wasn't open), register anchor markers for that
// file's matches so subsequent edits to it keep them in sync (#2583).
// Keep the results current when a file the panel is about changes — above
// all when the replace itself is undone, which puts every replaced match
// back in one bulk edit (no `after_insert` / `after_delete` fires for it).
// Only edits to the source file, a file with results, or a file the last
// replace rewrote re-run the search; typing elsewhere leaves it alone.
editor.on("buffer_modified", (args) => {
  // The panel of the window the buffer belongs to.
  const p = panels.get(args.window_id);
  if (!p || !p.searchPattern || args.buffer_id === p.resultsBufferId) return true;
  if (p === panel) {
    if (!p.replaceInProgress && panelWatchesBuffer(args.buffer_id)) rerunSearchDebounced(true);
    return true;
  }
  // A background window's file changed: re-search when the window is back.
  const path = editor.listBuffers(p.windowId).find((b) => b.id === args.buffer_id)?.path;
  if (
    args.buffer_id === p.sourceBufferId
    || (path && (p.parked?.replacedFiles.has(path) || p.fileGroups.some((g) => g.absPath === path)))
  ) {
    p.stale = true;
  }
  return true;
});

function panelWatchesBuffer(bufferId: number): boolean {
  if (!panel) return false;
  if (bufferId === panel.sourceBufferId) return true;
  const path = editor.getBufferPath(bufferId);
  if (!path) return false;
  return lastReplacedFiles.has(path) || panel.fileGroups.some((g) => g.absPath === path);
}

editor.on("after_file_open", (args) => {
  // The window the file opened in; its panel's matches in that file.
  const p = panels.get(args.window_id);
  if (p) ensureMarkersForPath(p, args.path, args.buffer_id);
  return true;
});

// Click → semantic event. The host hit-tests mouse clicks against the
// mounted widget panel and fires `widget_event` for clicks that land
// on a Toggle or Button. We dispatch on `widget_key` (set in
// `buildOptionsRowSpec`); the existing keyboard-driven path
// (Alt+C / Alt+R / Alt+W / Alt+Ret) still works unchanged.
//
// Mouse-click on a toggle should also focus it, so the user's next
// Tab cycle starts from the clicked control. We do that by syncing
// `focusPanel`/`optionIndex` to the clicked widget before applying
// the state change.
editor.on("widget_event", (args) => {
  if (confirmDialog && args.panel_id === confirmDialog.panel.id()) {
    if (args.event_type === "cancel") {
      // Esc / click outside / [×]: the host has already unmounted it.
      settleConfirmDialog(false, false);
    } else if (args.event_type === "activate") {
      if (args.widget_key === "confirmReplace") settleConfirmDialog(true);
      else if (args.widget_key === "confirmCancel") settleConfirmDialog(false);
    }
    return;
  }
  if (!panel || args.panel_id !== panel.widgetPanel?.id()) return;

  // `change` — fired for TextInput edits (Backspace, Delete,
  // arrows, Home/End, mode_text_input). Payload carries the new
  // value and cursor byte offset. The host already updated the
  // widget's instance state in place; we just sync the plugin's
  // model. **No** `updatePanelContent()` here — the widget has
  // already painted, and the rest of the spec doesn't depend on
  // the field value. This is the IPC fast path discussed in §3
  // of the design doc Q&A.
  if (args.event_type === "change") {
    const payload = args.payload as
      | { value?: string; cursorByte?: number }
      | undefined;
    if (typeof payload?.value !== "string") return;
    const cursorByte = typeof payload.cursorByte === "number"
      ? payload.cursorByte
      : payload.value.length;
    if (args.widget_key === "searchField") {
      if (panel.searchPattern !== payload.value) {
        // Pattern mutated by the user; cached "no matches" / result
        // set no longer reflects this query. See §17.
        panel.searchPerformed = false;
        // User-driven typing exits any in-flight history walk so a
        // subsequent Up doesn't snap back to a history entry under
        // the cursor. See §11.
        historyIndex = -1;
        historySavedPattern = null;
        panel.searchPattern = payload.value;
        panel.cursorPos = byteToCharOffset(payload.value, cursorByte);
        updatePanelContent();
        rerunSearchDebounced();
        scheduleHistoryPush(payload.value);
        return;
      }
      // Cursor-only update (Left/Right arrows, Home/End, click reposition):
      // the search field's text is unchanged, so don't re-run the search
      // or perturb the history-settle timer. Just sync the plugin's
      // cached cursor position so the next render shows the cursor in
      // the right place.
      panel.cursorPos = byteToCharOffset(payload.value, cursorByte);
    } else if (args.widget_key === "replaceField") {
      panel.replaceText = payload.value;
      panel.cursorPos = byteToCharOffset(payload.value, cursorByte);
    } else if (args.widget_key === "fileGlobField") {
      if (panel.fileGlob !== payload.value) {
        panel.fileGlob = payload.value;
        panel.searchPerformed = false;
        rerunSearchDebounced();
      }
    }
    return;
  }

  // `select` — fired when the user clicks a Tree row or the host
  // moves selection (Up/Down). The host already updated the
  // tree's selectedIndex in instance state; mirror it into the
  // plugin model. A *mouse click* (payload `via: "click"`) should
  // also act on the row — open the match / toggle the file — so
  // clicking a result jumps to it in the editor, matching user
  // expectation (issue #2434 follow-up). Keyboard arrow-moves carry
  // no `via` marker and only move the highlight.
  if (args.event_type === "select") {
    const payload = args.payload as { index?: number; via?: string } | undefined;
    const idx = payload?.index;
    if (typeof idx === "number") {
      panel.matchIndex = idx;
      if (payload?.via === "click") {
        activateTreeItem(idx).catch((e) => editor.error(`search-replace: ${e}`));
      }
    }
    return;
  }

  // `expand` — fired when the host changes a Tree node's
  // expansion state (Right/Left key, or click on the disclosure
  // glyph). Mirror the change into our local set so a subsequent
  // file-row Enter (which goes through `setExpandedKeys`) reads
  // the right state.
  if (args.event_type === "expand") {
    const payload = args.payload as
      | { key?: string; expanded?: boolean }
      | undefined;
    if (typeof payload?.key === "string" && typeof payload.expanded === "boolean") {
      if (payload.expanded) panel.expandedFileKeys.add(payload.key);
      else panel.expandedFileKeys.delete(payload.key);
    }
    return;
  }

  // `activate` — fired by Enter/Space on a focused Button or Tree.
  // For the Replace All button: run replace. For the matchTree:
  // open the focused match's source location, or toggle expansion
  // for file rows (so Enter is a shortcut for Right/Left/click).
  if (args.event_type === "activate") {
    if (args.widget_key === "replaceAll") {
      doReplaceAll();
      return;
    }
    if (args.widget_key === "matchTree") {
      const idx = (args.payload as { index?: number } | undefined)?.index;
      if (typeof idx !== "number") return;
      activateTreeItem(idx).catch((e) => editor.error(`search-replace: ${e}`));
      return;
    }
  }

  // `toggle` — fired by Enter/Space on a Toggle and by mouse click.
  // The host fires the event but doesn't mutate the spec's
  // `checked` field — the plugin owns its model and pushes the
  // new state back via the targeted `setChecked` mutator (cheaper
  // than a full spec re-emit). The search rerun happens
  // independently on debounce; when it finishes it re-emits the
  // full spec with new matches.
  if (args.event_type === "toggle") {
    const newChecked = (args.payload as { checked?: boolean } | undefined)
      ?.checked;
    if (typeof newChecked !== "boolean") return;
    switch (args.widget_key) {
      case "allFiles":
        // Scope flip (§1). Push the new checked state back to the
        // widget instance and rebuild the whole spec so the scope
        // row + Replace All button label switch in lock-step. Then
        // re-run the search so the results pane reflects the new
        // scope (the search itself is project-wide; filtering
        // happens in performSearch).
        panel.allFiles = newChecked;
        panel.widgetPanel?.setChecked("allFiles", newChecked);
        updatePanelContent();
        rerunSearchDebounced();
        break;
      case "case":
        panel.caseSensitive = newChecked;
        sessionMatchOptions.caseSensitive = newChecked;
        panel.widgetPanel?.setChecked("case", newChecked);
        rerunSearchDebounced();
        break;
      case "regex":
        panel.useRegex = newChecked;
        sessionMatchOptions.useRegex = newChecked;
        panel.widgetPanel?.setChecked("regex", newChecked);
        rerunSearchDebounced();
        break;
      case "whole":
        panel.wholeWords = newChecked;
        sessionMatchOptions.wholeWords = newChecked;
        panel.widgetPanel?.setChecked("whole", newChecked);
        rerunSearchDebounced();
        break;
      case "matchTree": {
        // The `[v]`/`[ ]` glyph on a tree row was clicked. Plugin
        // owns the source-of-truth (`result.selected`) — flip it
        // and push the new spec state via the targeted mutator.
        // For file rows we cascade to every child match so a
        // single click on the file checkbox checks/unchecks the
        // whole file's matches at once.
        const idx = (args.payload as { index?: number } | undefined)?.index;
        if (typeof idx !== "number") return;
        applyMatchTreeToggle(idx, newChecked);
        break;
      }
    }
  }
});

/// Toggle the selected state of a match-tree row at `idx` to
/// `newChecked`. For a match row, just flips that match. For a
/// file header, cascades to every child match. Updates the host's
/// view via `setCheckedKeys` (one call per row that changed
/// glyph) so the next render reflects the new state without a
/// full spec re-emit.
function applyMatchTreeToggle(idx: number, newChecked: boolean): void {
  if (!panel) return;
  const flat = buildFlatItems();
  const item = flat[idx];
  if (!item) return;
  if (item.type === "match") {
    const fileGroup = panel.fileGroups[item.fileIndex];
    fileGroup.matches[item.matchIndex!].selected = newChecked;
    const matchKey = flatItemKey(item);
    panel.widgetPanel?.setCheckedKeys("matchTree", newChecked, [matchKey]);
    // The file header's checked glyph is derived (all-or-nothing).
    // After flipping a single match, recompute and push the file
    // row's new state so it stays in sync with its children.
    const fileAllSelected = fileGroup.matches.every(m => m.selected);
    const fileKey = flatItemKey({ type: "file", fileIndex: item.fileIndex });
    panel.widgetPanel?.setCheckedKeys("matchTree", fileAllSelected, [fileKey]);
  } else {
    // File row — cascade to every child.
    const fileGroup = panel.fileGroups[item.fileIndex];
    for (const m of fileGroup.matches) m.selected = newChecked;
    const fileKey = flatItemKey(item);
    const matchKeys = fileGroup.matches.map((_, mi) =>
      flatItemKey({ type: "match", fileIndex: item.fileIndex, matchIndex: mi })
    );
    panel.widgetPanel?.setCheckedKeys(
      "matchTree",
      newChecked,
      [fileKey, ...matchKeys],
    );
  }
}

// Convert a UTF-8 byte offset into a JS-string character offset,
// because the host's TextInput cursor model uses bytes (matching the
// inline-overlay coordinate space) but the plugin's existing code
// stores `panel.cursorPos` as a char offset. Pure walk over the
// string until we hit `byteOffset`.
function byteToCharOffset(value: string, byteOffset: number): number {
  let bytes = 0;
  for (let i = 0; i < value.length; i++) {
    if (bytes >= byteOffset) return i;
    bytes += byteLen(value[i]);
  }
  return value.length;
}

editor.registerCommand(
  "%cmd.search_replace",
  "%cmd.search_replace_desc",
  "start_search_replace",
  null
);

editor.registerCommand(
  "%cmd.search_replace_in_buffer",
  "%cmd.search_replace_in_buffer_desc",
  "start_search_replace_in_buffer",
  null
);

// Match navigation (issue #2434). Always visible — these operate on the
// last search's results and are most useful from the editor while
// reviewing matches, so no panel context is required. Default bindings
// live in keymaps/default.json (Ctrl+Alt+Right / Ctrl+Alt+Left).
editor.registerCommand(
  "%cmd.next_match",
  "%cmd.next_match_desc",
  "search_replace_next_match",
  null
);

editor.registerCommand(
  "%cmd.prev_match",
  "%cmd.prev_match_desc",
  "search_replace_prev_match",
  null
);

editor.debug("Search & Replace plugin loaded");
